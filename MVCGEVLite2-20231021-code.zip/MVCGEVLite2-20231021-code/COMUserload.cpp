// COMUserload.cpp : implementation file
//

#include "stdafx.h"
#include "MVCGEVLite.h"
#include "MVCGEVLiteDlg.h"
#include "COMUserload.h"

extern CMVCGEVLiteDlg *pDemoDlg; //��������

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCOMUserload dialog


CCOMUserload::CCOMUserload(CWnd* pParent /*=NULL*/)
	: CDialog(CCOMUserload::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCOMUserload)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCOMUserload::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCOMUserload)
	DDX_Control(pDX, IDC_CMB_PowerOn, m_CMBPoweron);
	DDX_Control(pDX, IDC_CMB_UserData, m_CMBUserload);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCOMUserload, CDialog)
	//{{AFX_MSG_MAP(CCOMUserload)
	ON_BN_CLICKED(IDC_BTN_UsrDataSave, OnBTNUsrDataSave)
	ON_BN_CLICKED(IDC_BTN_UsrDataLoad, OnBTNUsrDataLoad)
	ON_BN_CLICKED(IDC_BTN_PowerOnSave, OnBTNPowerOnSave)
	ON_BN_CLICKED(IDC_BTN_DataReset, OnBTNDataReset)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCOMUserload message handlers

void CCOMUserload::OnBTNUsrDataSave() 
{
	m_iUserdata = m_CMBUserload.GetCurSel();
	if(m_iUserdata == -1)
	{
		MessageBox("����ѡ���û���");
	}
	else if(m_iUserdata == 0)
	{
		MessageBox("���ܽ��������浽Default��, ��ѡ���û���0��1��2");
	}
	else
	{
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SAVEDEFAULT,m_iUserdata);
		CString StrTmp;
		StrTmp = "�û�����������ɹ�!";
		MessageBox(StrTmp);
	}
}

void CCOMUserload::OnBTNUsrDataLoad() 
{
	m_iUserdata = m_CMBUserload.GetCurSel();
	if(m_iUserdata == -1)
	{
		MessageBox("����ѡ���û���");
		return;
	}
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_LOADDEFAULT,m_iUserdata);
	CString StrTmp;
	if(m_iUserdata!=0)
	{
		StrTmp = "�û����������سɹ�!";
	}
	else
	{
		StrTmp = "Default�������سɹ�!";
	}
	if(pDemoDlg->m_pCOMCam->GetSafeHwnd())
	{
		pDemoDlg->m_pCOMCam->InitParamCOMCamera();
	}
	if(pDemoDlg->m_pCOMFpga->GetSafeHwnd())
	{
		pDemoDlg->m_pCOMFpga->InitParamCOMFpga();
	}
	MessageBox(StrTmp);
}

void CCOMUserload::OnBTNPowerOnSave() 
{
	m_iPowerOn = m_CMBPoweron.GetCurSel();
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_POWERON_LOAD,m_iPowerOn);
	CString StrTmp;
	if(m_iPowerOn!=0)
	{
		StrTmp = "�ϵ�����û����������óɹ�!";
	}
	else
	{
		StrTmp = "�ϵ����Default�������óɹ�!";
	}
	MessageBox(StrTmp);	
}

void CCOMUserload::OnBTNDataReset() 
{
	if(MessageBox("��λ���������������û���������Ĭ��ֵ,�Ƿ����?","ע��",MB_OKCANCEL)!=IDOK) return;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_LOADDEFAULT,0); //��ȡDefault����
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SAVEDEFAULT,1);//��Default��������User0
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SAVEDEFAULT,2);//��Default��������User1
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SAVEDEFAULT,3);//��Default��������User2
	if(pDemoDlg->m_pCOMCam->GetSafeHwnd())
	{
		pDemoDlg->m_pCOMCam->InitParamCOMCamera();
	}
	if(pDemoDlg->m_pCOMFpga->GetSafeHwnd())
	{
		pDemoDlg->m_pCOMFpga->InitParamCOMFpga();
	}
	MessageBox("�����û���������λ�ɹ�!");
}

void CCOMUserload::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	m_iPowerOn = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_POWERON_LOAD);
	m_CMBPoweron.SetCurSel(m_iPowerOn);
}

BOOL CCOMUserload::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_iUserdata = -1;
	m_iPowerOn = -1;
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CCOMUserload::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_ESCAPE) 
	{ 
		return TRUE; 
	} 

	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_RETURN) 
	{ 
		return TRUE; 
	} 
	else 
	{ 
		return CDialog::PreTranslateMessage(pMsg); 
	}
}
