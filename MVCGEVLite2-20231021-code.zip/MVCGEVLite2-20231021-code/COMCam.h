#include "afxwin.h"
#include "afxcmn.h"
#if !defined(AFX_COMCAM_H__1614B054_023A_4F28_9135_42A77277072F__INCLUDED_)
#define AFX_COMCAM_H__1614B054_023A_4F28_9135_42A77277072F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// COMCam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCOMCam dialog

class CCOMCam : public CDialog
{
// Construction
public:
	CCOMCam(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCOMCam)
	enum { IDD = IDD_DLG_CAM };
	CComboBox	m_CMBBinning;
	CComboBox	m_CMBHdr;
	CButton	m_CHKFlipUD;
	CButton	m_CHKFlipLR;
	CButton	m_CHKClamp;
	CComboBox	m_CMBShutterType;
	CSliderCtrl	m_SLDExp;
	CSliderCtrl	m_SLDDGain;
	CSliderCtrl	m_SLDAGain;
	int		m_iAGain;
	int		m_iDGain;
	int		m_iExp;
	int		m_iXOffset;
	int		m_iYOffset;
	int		m_iWidth;
	int		m_iHeight;
	//}}AFX_DATA

	void InitParamCOMCamera();	//��ȡSensor����

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCOMCam)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCOMCam)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnChkClamp();
	afx_msg void OnCHKFlipLR();
	afx_msg void OnCHKFlipUD();
	afx_msg void OnSelchangeCMBWorkMode();
	afx_msg void OnBtnSize();
	afx_msg void OnSelchangeCmbHdr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedChkAec();
	afx_msg void OnBnClickedChkAgc();
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	CButton m_CHKAEC;
	CButton m_CHKAGC;
public:
	afx_msg void OnBnClickedBtnAgain();
public:
	afx_msg void OnBnClickedBtnDgain();
public:
	afx_msg void OnBnClickedBtnExp();
public:
	afx_msg void OnBnClickedBtnExpabs();
public:
	CSliderCtrl m_SLDExpAbs;
public:
	int m_iExpAbs;
public:
	BOOL m_bIrisEnable;
public:
	BOOL m_bFocusEnable;
public:
	CSliderCtrl m_SLDIris;
public:
	CSliderCtrl m_SLDFocus;
public:
	int m_iIris;
public:
	int m_iFocus;
public:
	afx_msg void OnBnClickedChkIris();
public:
	afx_msg void OnBnClickedBtnIris();
public:
	afx_msg void OnBnClickedChkFocus();
public:
	afx_msg void OnBnClickedBtnFocus();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMCAM_H__1614B054_023A_4F28_9135_42A77277072F__INCLUDED_)
