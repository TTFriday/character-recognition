#if !defined(AFX_COMUSERLOAD_H__FC174ED0_C63B_4E7F_BEE8_F1DB7C58C7A3__INCLUDED_)
#define AFX_COMUSERLOAD_H__FC174ED0_C63B_4E7F_BEE8_F1DB7C58C7A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// COMUserload.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCOMUserload dialog

class CCOMUserload : public CDialog
{
// Construction
public:
	CCOMUserload(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCOMUserload)
	enum { IDD = IDD_DLG_USER };
	CComboBox	m_CMBPoweron;
	CComboBox	m_CMBUserload;
	//}}AFX_DATA

	int m_iUserdata;
	int m_iPowerOn;



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCOMUserload)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCOMUserload)
	afx_msg void OnBTNUsrDataSave();
	afx_msg void OnBTNUsrDataLoad();
	afx_msg void OnBTNPowerOnSave();
	afx_msg void OnBTNDataReset();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMUSERLOAD_H__FC174ED0_C63B_4E7F_BEE8_F1DB7C58C7A3__INCLUDED_)
