/** 
 * @GE Device Pub Function
 * @Version 2.2
 * @Build 20111224
 * @Author tank@mircoview.com.cn
 */
#pragma once

//1.Convector
CString Int2Cstr(int num);//Int2CString
CString Int2Cstr(int num, int lens);//Int2CString
CString Float2Cstr(double num);//FloatתCString 4.1f
void	ChangeBit(DWORD& DataInt,int pos,int val); //���BITλ

//2.TimeString
void	GetTimeAsFileName(char *FileName);//ms
void	GetTimeAsFileName(CString& FileName);//ms
void	GetTimeAsFileNameS(char *FileName);//s

//3.Debug
void	DumpInfo(const char * strOutputString,...); //VA���

//4.File
CString GetSelFolder(); //��ȡѡ��Ŀ¼
void	MakeFolder(CString lPath); //ȷ��·������
BOOL	ReadFile(CString lFileName, PBYTE &lDestBuf, DWORD &lLens);
BOOL	WriteFile(CString lFileName, PBYTE lSrctBuf, DWORD lLens);
