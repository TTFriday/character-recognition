#include "stdafx.h"
#include <direct.h>
#include "../Include/MVFunction.h"

/*-----------------------------------------------------------------------------------
 1.Convector
 ----------------------------------------------------------------------------------*/
CString Int2Cstr(int num)
{
	CString ks;
	ks.Format("%u",num);
	return ks;
}

CString Int2Cstr(int num, int lens)
{
	CString ls = "%0"+Int2Cstr(lens)+"u";
	CString ks;
	ks.Format(ls,num);
	return ks;
}

CString Float2Cstr(double num)
{
	CString ks;
	ks.Format("%4.1f",num);
	return ks;
}

void ChangeBit(DWORD& DataInt,int pos,int val)
{
	int flag = (DataInt>>pos)&0x1;
	if(flag>val)//1>0
	{
		DataInt = DataInt - (1<<pos);
	}
	else if(flag<val)//0<1
	{
		DataInt = DataInt + (1<<pos);
	}
}

/*-----------------------------------------------------------------------------------
 2.TimeString
 ----------------------------------------------------------------------------------*/
void GetTimeAsFileName(char *FileName)
{
	SYSTEMTIME st;
	CString strDate,strTime; 
	GetLocalTime(&st); 
	strDate.Format("%04d%02d%02d",st.wYear,st.wMonth,st.wDay); 
	strTime.Format("%02d%02d%02d%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	sprintf(FileName,"%s-%s",strDate,strTime);
}

void GetTimeAsFileName(CString& FileName)
{
	SYSTEMTIME st;
	CString strDate,strTime; 
	GetLocalTime(&st); 
	strDate.Format("%04d%02d%02d",st.wYear,st.wMonth,st.wDay); 
	strTime.Format("%02d%02d%02d%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	FileName.Format("%s-%s",strDate,strTime);
}

void GetTimeAsFileNameS(char *FileName)
{
	SYSTEMTIME st;
	CString strDate,strTime; 
	GetLocalTime(&st); 
	strDate.Format("%04d%02d%02d",st.wYear,st.wMonth,st.wDay); 
	strTime.Format("%02d%02d%02d",st.wHour,st.wMinute,st.wSecond);
	sprintf(FileName,"%s-%s",strDate,strTime);
}

/*-----------------------------------------------------------------------------------
 3.Debug
 ----------------------------------------------------------------------------------*/
CString GetSelFolder()
{
	char szSelected[MAX_PATH]; //��������ļ���·��
	CString m_strFileOut;
	BROWSEINFO bi;
	LPITEMIDLIST pidl;
	bi.hwndOwner = NULL;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = szSelected;
	bi.lpszTitle = "ѡ������ļ�·��";
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	bi.lpfn = NULL;
	bi.lParam = NULL;
	bi.iImage = NULL;
	if((pidl = SHBrowseForFolder(&bi)) != NULL)
	{
		if(SUCCEEDED(SHGetPathFromIDList(pidl, szSelected))) //�õ��ļ��е�ȫ·
		{
			m_strFileOut = szSelected;
			m_strFileOut += "\\";
		}
	}
	return m_strFileOut;
}

void DumpInfo(const char * strOutputString,...)
{
	char strBuffer[4096]={0};
	va_list vlArgs;
	va_start(vlArgs,strOutputString);
	_vsnprintf(strBuffer,sizeof(strBuffer)-1,strOutputString,vlArgs);
	va_end(vlArgs);
	OutputDebugString(strBuffer);
}

/*-----------------------------------------------------------------------------------
 4.File
 ----------------------------------------------------------------------------------*/
void MakeFolder(CString lPath)
{
	CFileFind find;
	if(!find.FindFile(lPath))
	{
		int i,len;
		char* p = "";
		sprintf(p,"%s",lPath);
		len=strlen(p);
		for(i=0;i<len;i++)
		{
			if(p[i]=='\\')
			{
				p[i]='\0';
				_mkdir(p);
				p[i]='\\';
			}
		}
		if(len>0)_mkdir(p);
	}
}

BOOL ReadFile(CString lFileName, PBYTE &lDestBuf, DWORD &lLens)
{
	if(lFileName == "")
	{
		CFileDialog *lpszOpenFile;    //����һ��CfileDialog����
		lpszOpenFile = new CFileDialog(TRUE,"","",OFN_FILEMUSTEXIST |OFN_HIDEREADONLY, "�ļ�����(*.*)|*.*||");

		if(lpszOpenFile->DoModal()==IDOK)//����Ի���ȷ����ť,���ļ�
		{
			CString szGetName;
			szGetName = lpszOpenFile->GetPathName();//�õ������ļ���·��
			//��ȡ�ļ�
			delete lpszOpenFile;//�ͷŷ���ĶԻ���
			return ReadFile(szGetName, lDestBuf, lLens);
		}
		else
		{
			delete lpszOpenFile;//�ͷŷ���ĶԻ���
			return -1;
		}
	}
	else
	{
		CFile file;
		if(file.Open(lFileName,CFile::modeRead|CFile::typeBinary))
		{
			lLens = (DWORD)file.GetLength(); //��ȡ�ļ�����
			if(lDestBuf==NULL)
			{
				lDestBuf = new BYTE[lLens];
			}
			file.Read(lDestBuf,lLens);
			file.Close();
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}

BOOL WriteFile(CString lFileName, PBYTE lSrcBuf, DWORD lLens)
{
	
	CString lFullPath = lFileName;
	int lNameLens = lFullPath.GetLength();
	char* lFolderName = lFullPath.GetBuffer(lNameLens);
	while((lFolderName[lNameLens] != 92)&&(lNameLens > 0))
	{
		lFolderName[lNameLens] = 0;
		lNameLens--;
	}
	//DumpInfo("lFileName is %s lFolderName is %s",lFileName,lFolderName);
	MakeFolder(lFolderName);
	
	CFile file;
	if(file.Open(lFileName,CFile::typeBinary|CFile::modeWrite|CFile::modeCreate))
	{
		file.Write(lSrcBuf,lLens);
		file.Close();
		return TRUE;
	}
	else
	{
		DumpInfo("file.Open fail!");
		return FALSE;
	}
}
