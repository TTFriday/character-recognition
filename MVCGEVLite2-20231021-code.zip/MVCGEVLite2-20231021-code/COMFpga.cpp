// COMFpga.cpp : implementation file
//

#include "stdafx.h"
#include "MVCGEVLite.h"
#include "MVCGEVLiteDlg.h"
#include "COMFpga.h"

extern CMVCGEVLiteDlg *pDemoDlg; //��������

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCOMFpga dialog


CCOMFpga::CCOMFpga(CWnd* pParent /*=NULL*/)
	: CDialog(CCOMFpga::IDD, pParent)
	, m_iBright(0)
	, m_iContrast(0)
	, m_iFlashDelay(0)
	, m_iFlashWidth(0)
	, m_iTrigPolarity(0)
	, m_iFlashPolarity(0)
	, m_bFlashOut(FALSE)
	, m_bTimer(FALSE)
	, m_iColorEnhance(0)
	, m_iColorFormat(0)
	, m_iAWBStartX(0)
	, m_iAWBStartY(0)
	, m_iAWBEndX(0)
	, m_iAWBEndY(0)
	, m_iSkipFrame(0)
	, m_iSoftTrigMode(0)
	, m_iUnit(-1)
	, m_iFilterMode(0)
	, m_iUserOutSelect(0)
	, m_bUserOutEnable(FALSE)
	, m_bUserOutInvert(FALSE)
	, m_iHueEnhance(0)
	, m_bEnhanceEnable(FALSE)
	, m_iShapenMode(0)
	, m_iCapFpsMax(0)
	, m_iAWBRatioRG(0)
	, m_iAWBRatioBG(0)
	, m_bGammaEnable(FALSE)
	, m_iGamma(0)
	, m_iTestPattern(0)
	, m_iADLimitHigh(0)
	, m_iADLimitLow(0)
	, m_bADLimit(FALSE)
	, m_iLimitLow(0)
	, m_iLimitHigh(0)
	, m_iADKneePoint(0)
	, m_iKneePoint(0)
	, m_bFpsControl(FALSE)
	, m_iLedEnable(0)
{
	//{{AFX_DATA_INIT(CCOMFpga)
	m_iDebouce = 0;
	m_iTrigNumber = 0;
	m_iTrigDelay = 0;
	m_iTrigInterval = 0;
	m_iTrigWidth = 0;
	//}}AFX_DATA_INIT
}


void CCOMFpga::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCOMFpga)
	DDX_Control(pDX, IDC_CMB_BITLut, m_CMBLut);
	DDX_Text(pDX, IDC_EDT_DebounceWidth, m_iDebouce);
	DDX_Text(pDX, IDC_EDT_TriggerMultiple, m_iTrigNumber);
	DDX_Text(pDX, IDC_EDT_TrigDelay, m_iTrigDelay);
	DDX_Text(pDX, IDC_EDT_TrigInterval, m_iTrigInterval);
	DDX_Text(pDX, IDC_EDT_TrigWidth, m_iTrigWidth);
	DDX_Text(pDX, IDC_EDT_Bright, m_iBright);
	DDX_Text(pDX, IDC_EDT_Contrast, m_iContrast);
	DDX_Text(pDX, IDC_EDT_Temperature, m_sTemperature);
	DDX_Text(pDX, IDC_EDT_FlashDelay, m_iFlashDelay);
	DDX_Text(pDX, IDC_EDT_TrigDelay3, m_iFlashWidth);
	DDX_CBIndex(pDX, IDC_CMB_TrigPolarity, m_iTrigPolarity);
	DDX_CBIndex(pDX, IDC_CMB_FlashPolarity, m_iFlashPolarity);
	DDX_Check(pDX, IDC_CHK_FLASH, m_bFlashOut);
	DDX_Check(pDX, IDC_CHK_Temperature, m_bTimer);
	DDX_Text(pDX, IDC_EDT_ColorEnhance, m_iColorEnhance);
	DDX_Text(pDX, IDC_EDT_AWBStartX, m_iAWBStartX);
	DDX_Text(pDX, IDC_EDT_AWBStartY, m_iAWBStartY);
	DDX_Text(pDX, IDC_EDT_AWBEndX, m_iAWBEndX);
	DDX_Text(pDX, IDC_EDT_AWBEndY, m_iAWBEndY);
	DDX_Control(pDX, IDC_CMB_ColorFormat, m_pColorFormat);
	DDX_Text(pDX, IDC_EDT_SkipNum, m_iSkipFrame);
	DDX_CBIndex(pDX, IDC_CMB_SoftTrig, m_iSoftTrigMode);
	DDX_CBIndex(pDX, IDC_CMB_Unit, m_iUnit);
	DDX_CBIndex(pDX, IDC_CMB_FilterMode, m_iFilterMode);
	DDX_CBIndex(pDX, IDC_CMB_UserOut, m_iUserOutSelect);
	DDX_Check(pDX, IDC_CHK_UserOutEnable, m_bUserOutEnable);
	DDX_Check(pDX, IDC_CHK_UserOutInvert, m_bUserOutInvert);
	DDX_Text(pDX, IDC_EDT_HueEnhance, m_iHueEnhance);
	DDX_Check(pDX, IDC_CHK_Enhance, m_bEnhanceEnable);
	DDX_CBIndex(pDX, IDC_CMB_SharpenMode, m_iShapenMode);
	DDX_Text(pDX, IDC_EDT_CapFpsMax, m_iCapFpsMax);
	DDX_Text(pDX, IDC_EDT_AWBRatioRG, m_iAWBRatioRG);
	DDX_Text(pDX, IDC_EDT_AWBRatioBG, m_iAWBRatioBG);
	DDX_Check(pDX, IDC_CHK_Gamma, m_bGammaEnable);
	DDX_Text(pDX, IDC_EDT_GammaRaw, m_iGamma);
	DDX_Control(pDX, IDC_CMB_TestPattern, m_pTestPattern);
	DDX_Text(pDX, IDC_EDT_ADLimitHigh, m_iADLimitHigh);
	DDX_Text(pDX, IDC_EDT_ADLimitLow, m_iADLimitLow);
	DDX_Check(pDX, IDC_CHK_ADLimitManual, m_bADLimit);
	//}}AFX_DATA_MAP
	DDX_Slider(pDX, IDC_SLD_LimitLow, m_iLimitLow);
	DDV_MinMaxInt(pDX, m_iLimitLow, 0, 16383);
	DDX_Slider(pDX, IDC_SLD_LimitHigh, m_iLimitHigh);
	DDV_MinMaxInt(pDX, m_iLimitHigh, 0, 16383);
	DDX_Text(pDX, IDC_EDT_ADKneePoint, m_iADKneePoint);
	DDX_Slider(pDX, IDC_SLD_KneePoint, m_iKneePoint);
	DDX_Check(pDX, IDC_CHK_FpsControl, m_bFpsControl);
	DDX_Control(pDX, IDC_CMB_LED, m_pLEDEnable);
	DDX_CBIndex(pDX, IDC_CMB_LED, m_iLedEnable);
}

BEGIN_MESSAGE_MAP(CCOMFpga, CDialog)
	//{{AFX_MSG_MAP(CCOMFpga)
	ON_BN_CLICKED(IDC_BTN_SoftTrigger, OnBTNSoftTrigger)
	ON_BN_CLICKED(IDC_BTN_SoftReset, OnBTNSoftReset)
	ON_CBN_SELCHANGE(IDC_CMB_BITLut, OnSelchangeCMBBITLut)
	ON_EN_CHANGE(IDC_EDT_DebounceWidth, OnChangeEDTDebounceWidth)
	ON_WM_SHOWWINDOW()
	ON_EN_CHANGE(IDC_EDT_TrigDelay, OnChangeEDTTrigDelay)
	ON_EN_CHANGE(IDC_EDT_TrigInterval, OnChangeEDTTrigInterval)
	ON_EN_CHANGE(IDC_EDT_TrigWidth, OnChangeEDTTrigWidth)
	ON_BN_CLICKED(IDC_CHK_FLASH, OnBnClickedChkFlash)
	ON_BN_CLICKED(IDC_CHK_DefectRemove, OnBnClickedChkDefectremove)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_CBN_SELCHANGE(IDC_CMB_TrigPolarity, OnCbnSelchangeCmbTrigpolarity)
	ON_EN_CHANGE(IDC_EDT_FlashDelay, OnEnChangeEdtFlashdelay)
	ON_CBN_SELCHANGE(IDC_CMB_FlashPolarity, OnCbnSelchangeCmbFlashpolarity)
	ON_EN_CHANGE(IDC_EDT_FlashWidth, OnEnChangeEdtFlashwidth)
	ON_BN_CLICKED(IDC_CHK_Temperature, OnBnClickedChkTemperature)
	ON_BN_CLICKED(IDC_BTN_AWB, OnBnClickedBtnAwb)
	ON_CBN_SELCHANGE(IDC_CMB_ColorFormat, OnCbnSelchangeCmbColorformat)
	ON_CBN_SELCHANGE(IDC_CMB_SoftTrig, OnCbnSelchangeCmbSofttrig)
	ON_CBN_SELCHANGE(IDC_CMB_FilterMode, OnCbnSelchangeCmbFiltermode)
	ON_CBN_SELCHANGE(IDC_CMB_Unit, OnCbnSelchangeCmbUnit)
	ON_CBN_SELCHANGE(IDC_CMB_UserOut, OnCbnSelchangeCmbUserout)
	ON_BN_CLICKED(IDC_CHK_UserOutEnable, OnBnClickedChkUseroutenable)
	ON_BN_CLICKED(IDC_CHK_UserOutInvert, OnBnClickedChkUseroutinvert)
	ON_BN_CLICKED(IDC_BTN_AWBReset, OnBnClickedBtnAwbreset)
	ON_BN_CLICKED(IDC_CHK_Enhance, OnBnClickedChkEnhance)
	ON_CBN_SELCHANGE(IDC_CMB_SharpenMode, OnCbnSelchangeCmbSharpenmode)
	ON_BN_CLICKED(IDC_CHK_Gamma, OnBnClickedChkGamma)
	ON_BN_CLICKED(IDC_BTN_TrigNum, OnBnClickedBtnTrignum)
	ON_BN_CLICKED(IDC_BTN_SkipNum, OnBnClickedBtnSkipnum)
	ON_BN_CLICKED(IDC_BTN_MaxFPS, OnBnClickedBtnMaxfps)
	ON_BN_CLICKED(IDC_BTN_Saturation, OnBnClickedBtnSaturation)
	ON_BN_CLICKED(IDC_BTN_Hue, OnBnClickedBtnHue)
	ON_BN_CLICKED(IDC_BTN_Gamma, OnBnClickedBtnGamma)
	ON_BN_CLICKED(IDC_BTN_AWBApply, OnBnClickedBtnAwbapply)
	ON_BN_CLICKED(IDC_BTN_Bright, OnBnClickedBtnBright)
	ON_BN_CLICKED(IDC_BTN_Contrast, OnBnClickedBtnContrast)
	ON_CBN_SELCHANGE(IDC_CMB_TestPattern, OnCbnSelchangeCmbTestpattern)
	ON_BN_CLICKED(IDC_BTN_ADLimitHigh, OnBnClickedBtnAdlimithigh)
	ON_BN_CLICKED(IDC_BTN_ADLimitLow, OnBnClickedBtnAdlimitlow)
	ON_BN_CLICKED(IDC_CHK_ADLimitManual, OnBnClickedChkAdlimitmanual)
	//}}AFX_MSG_MAP
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BTN_ADKneePoint, &CCOMFpga::OnBnClickedBtnAdkneepoint)
	ON_BN_CLICKED(IDC_CHK_FpsControl, &CCOMFpga::OnBnClickedChkFpscontrol)
	ON_CBN_SELCHANGE(IDC_CMB_LED, &CCOMFpga::OnCbnSelchangeCmbLed)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCOMFpga message handlers

void CCOMFpga::OnBTNSoftTrigger() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SOFTTRIGGER,m_iSoftTrigMode+1);
}

void CCOMFpga::OnBTNSoftReset() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORRESET,1);
	InitParamCOMFpga();
	if(pDemoDlg->m_pCOMCam->GetSafeHwnd())
	{
		pDemoDlg->m_pCOMCam->InitParamCOMCamera();
	}
}

void CCOMFpga::OnSelchangeCMBBITLut() 
{
	if(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000)
	{
		int lValue = m_CMBLut.GetItemData( m_CMBLut.GetCurSel());
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_BITLUT,lValue);
	}
	else if(pDemoDlg->m_iDevSeries == HK2400_S)
	{
		int lValue = m_CMBLut.GetItemData( m_CMBLut.GetCurSel());
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_BITLUT,lValue);
	}
	else
	{
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_BITLUT,m_CMBLut.GetCurSel());
	}
}

void CCOMFpga::OnChangeEDTDebounceWidth() 
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_PLUSEWIDTH,m_iDebouce);
}

void CCOMFpga::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	InitParamCOMFpga();
}

void CCOMFpga::InitParamCOMFpga()
{
	m_iDebouce		 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_PLUSEWIDTH);
	m_iTrigNumber	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGPICNUM);
	m_iTrigDelay	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_DELAY);
	m_iTrigInterval	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGERDELAY);
	m_iTrigWidth	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_PULSEWIDTH);
	m_iTrigPolarity  = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_POLARITY);

	m_iFlashWidth	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASHWIDTH);
	m_iFlashDelay	 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASHDELAY);
	m_iFlashPolarity = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASH_POLARITY);
	m_bFlashOut		 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_STROBEOUT);

	if(pDemoDlg->m_iDevType == RS_A1300_GM60 || pDemoDlg->m_iDevType == RS_A1300_GC60
	|| pDemoDlg->m_iDevType == RS_A2300_GM50 || pDemoDlg->m_iDevType == RS_A2300_GC50
	|| pDemoDlg->m_iDevType == RS_A2300_GM60 || pDemoDlg->m_iDevType == RS_A2300_GC60
	|| pDemoDlg->m_iDevType == RS_A5001_GM14 || pDemoDlg->m_iDevType == RS_A5001_GC14
	|| pDemoDlg->m_iDevType == RS_A1400_GM60 || pDemoDlg->m_iDevType == RS_A1400_GC60 
	|| pDemoDlg->m_iDevType == RS_A1500_GM60 || pDemoDlg->m_iDevType == RS_A2001_GM60
	|| pDemoDlg->m_iDevType == RS_A10K_GC7   || pDemoDlg->m_iDevType == RS_A10K_GM7	 
	|| pDemoDlg->m_iDevType == RS_A361_GC60  || pDemoDlg->m_iDevType == RS_A361_GM60
	|| pDemoDlg->m_iDevType == RS_A361_GC100 || pDemoDlg->m_iDevType == RS_A361_GM100
	|| pDemoDlg->m_iDevType == RS_A1000_GM30
	|| pDemoDlg->m_iDevType == RS_A363_GM150 || pDemoDlg->m_iDevType == RS_A363_GC150
	|| pDemoDlg->m_iDevType == RS_A14K_GC8
	|| pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30
	|| pDemoDlg->m_iDevType == RS_A1302_GM80 || pDemoDlg->m_iDevType == RS_A1302_GC80
	|| pDemoDlg->m_iDevType == RS_A301_GM387
	)
	{
		GetDlgItem(IDC_EDT_Temperature)->EnableWindow(1);
		GetDlgItem(IDC_CHK_Temperature)->EnableWindow(1);
		int l_iTemp		= MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCCAP_TEMPERATURE);
		m_sTemperature  = (l_iTemp>>8)&0x1?"-":"" + Int2Cstr(l_iTemp&0xff);
	}

	((CButton*)GetDlgItem(IDC_CHK_DefectRemove))->SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_NOISEREMOVE));
	
	if(pDemoDlg->m_iDevSeries != MV10K_S && pDemoDlg->m_iDevSeries != MV500_S && pDemoDlg->m_iDevType != RS_A10K_GC7 && pDemoDlg->m_iDevType != RS_A10K_GM7)
	{
		GetDlgItem(IDC_CHK_FLASH)->EnableWindow(1);
	}

	if(pDemoDlg->m_iDevSeries == MV10K_S || pDemoDlg->m_iDevSeries == MV1200_S
	 ||pDemoDlg->m_iDevSeries == RS5001_S|| pDemoDlg->m_iDevSeries == RS361_S || pDemoDlg->m_iDevSeries == RS1000_S || pDemoDlg->m_iDevSeries == RS1302_S)
	{
		GetDlgItem(IDC_CHK_DefectRemove)->EnableWindow(1);
		GetDlgItem(IDC_BTN_SoftReset)->EnableWindow(pDemoDlg->m_iDevType == MVC14KSAC_GE6_N || pDemoDlg->m_iDevType == MVC14KSAM_GE6_N);
	}
	else
	{
		GetDlgItem(IDC_CHK_DefectRemove)->EnableWindow(0);
		GetDlgItem(IDC_BTN_SoftReset)->EnableWindow(1);
	}

	int l_iBitLut = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_BITLUT);
	if((pDemoDlg->m_bRosa && pDemoDlg->m_iDevFW>=0x2000) || pDemoDlg->m_iDevSeries == HK2400_S)
	{
		GetDlgItem(IDC_BTN_SoftReset)->EnableWindow(0);
		for ( int i = 0; i < m_CMBLut.GetCount(); i++ )
		{
			DWORD_PTR lData = m_CMBLut.GetItemData( i );
			if ( lData == l_iBitLut )
			{
				m_CMBLut.SetCurSel( i );
				break;
			}
		}
		m_iGamma = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GAMMARAW);
		m_bGammaEnable = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GAMMAENABLE);
		if(pDemoDlg->m_bColor)
		{
			m_iAWBRatioRG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIORG);
			m_iAWBRatioBG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIOBG);
		}
		UpdateData(FALSE);
	}
	else
	{
		m_CMBLut.SetCurSel(l_iBitLut);
	}

	if(((pDemoDlg->m_iDevSeries == MV10K_S  || pDemoDlg->m_iDevSeries == MV1200_S
	 || pDemoDlg->m_iDevSeries == MV1300_S || pDemoDlg->m_iDevSeries == MV2300_S)
	 &&!pDemoDlg->m_bColor && pDemoDlg->m_iDevFW<0x2000)||(pDemoDlg->m_iDevSeries == RS1003_S)
	 ||(pDemoDlg->m_bRosa && pDemoDlg->m_iDevFW>=0x2100))
	{
		GetDlgItem(IDC_EDT_Bright)->EnableWindow(1);
		GetDlgItem(IDC_EDT_Contrast)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Bright)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Contrast)->EnableWindow(1);
		m_iBright		 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SBRIGHTNESS);
		m_iContrast		 = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SCONTRAST);
	}

	if(pDemoDlg->m_bRosa && pDemoDlg->m_iDevFW>=0x2100)
	{
		GetDlgItem(IDC_CHK_FpsControl)->EnableWindow(1);
		m_bFpsControl = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FPSMAXENABLE);
	}


	if((pDemoDlg->m_iDevSeries == MV1300_S || pDemoDlg->m_iDevSeries == MV2300_S)
	|| (pDemoDlg->m_bRosa && pDemoDlg->m_iDevFW>=0x2000))
	{
		m_iCapFpsMax = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FPSMAX);
		GetDlgItem(IDC_EDT_CapFpsMax)->EnableWindow(1);
		GetDlgItem(IDC_BTN_MaxFPS)->EnableWindow(1);
	}

	m_iSkipFrame = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_FRAMESKIP);

	if(m_bAlgEnable)
	{
		m_iAWBStartX		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSSTARTX);
		m_iAWBStartY		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSSTARTY);
		m_iAWBEndX			= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSENDX);
		m_iAWBEndY			= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSENDY);
		m_iAWBRatioRG		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIORG);
		m_iAWBRatioBG		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIOBG);
		m_bEnhanceEnable	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ENHANCEENABLE);
		m_iColorEnhance		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_COLORENHANCE);
		m_iHueEnhance		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_HUEENHANCE);
		m_iColorFormat		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IMAGEDATA);
		m_iUnit				= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IOUNIT);
		m_iFilterMode		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_DENOISING);
		m_iShapenMode		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SHARPNESS);
		m_iUserOutSelect	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTSELECT);
		m_bUserOutEnable	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTENABLE);
		m_bUserOutInvert	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTINVERT);
		m_iTestPattern		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_TESTPATTERN);
		for ( int i = 0; i < m_pColorFormat.GetCount(); i++ )
		{
			DWORD_PTR lData = m_pColorFormat.GetItemData( i );
			if ( lData == m_iColorFormat )
			{
				m_pColorFormat.SetCurSel( i );
				break;
			}
		}
		for ( int j = 0; j < m_pTestPattern.GetCount(); j++ )
		{
			DWORD_PTR lData = m_pTestPattern.GetItemData( j );
			if ( lData == m_iTestPattern )
			{
				m_pTestPattern.SetCurSel( j );
				break;
			}
		}
	}

	//RS_A1003 SPEC
	if(pDemoDlg->m_iDevSeries == RS1003_S || pDemoDlg->m_iDevSeries == CM1003_S)
	{
		m_iADLimitHigh = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITHIGH);
		m_iADLimitLow = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITLOW);
		m_bADLimit = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITENABLE);
		m_iADKneePoint = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADKNEEPOINT);
		m_iLimitLow = m_iADLimitLow;
		m_iLimitHigh = m_iADLimitHigh;
		m_iGamma = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GAMMARAW);
	}

	//CM_A1003 SPEC
	if(pDemoDlg->m_iDevSeries == CM1003_S)
	{
		m_iColorFormat		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IMAGEDATA);
		//m_iTestPattern		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_TESTPATTERN);
		for ( int i = 0; i < m_pColorFormat.GetCount(); i++ )
		{
			DWORD_PTR lData = m_pColorFormat.GetItemData( i );
			if ( lData == m_iColorFormat )
			{
				m_pColorFormat.SetCurSel( i );
				break;
			}
		}
		for ( int j = 0; j < m_pTestPattern.GetCount(); j++ )
		{
			DWORD_PTR lData = m_pTestPattern.GetItemData( j );
			if ( lData == m_iTestPattern )
			{
				m_pTestPattern.SetCurSel( j );
				break;
			}
		}
		m_pLEDEnable.SetCurSel(MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_LEDCONTROL));
	}

	UpdateData(FALSE);
}

BOOL CCOMFpga::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_bAlgEnable = FALSE;
	// TODO:  Add extra initialization here

	if((pDemoDlg->m_iDevType==MVC1340SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1340SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1400SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1400SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1400SANR_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1400SAV_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1450SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1450SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1480SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1480SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1500SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1500SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1500SANR_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1500SANR_GE6_N)
	 ||(pDemoDlg->m_iDevType==MVC1500SAV_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1550SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1550SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1580SAM_GE60_N)
	 ||(pDemoDlg->m_iDevType==MVC1580SAC_GE60_N)
	 ||(pDemoDlg->m_iDevType==RS_A2300_GM50)
	 ||(pDemoDlg->m_iDevType==RS_A2300_GC50)
	 ||(pDemoDlg->m_iDevType==RS_A2300_GM60)
	 ||(pDemoDlg->m_iDevType==RS_A2300_GC60)
	 )
	{
		if(pDemoDlg->m_iDevFW<0x2000)
		{
			m_CMBLut.AddString("[9:0]");
		}
	}

	if(pDemoDlg->m_iDevSeries == HK2400_S)
	{
		m_CMBLut.ResetContent();
		char* p[9] = {"[11:0]","[11:2]","[10:1]","[9:0]","[11:4]","[10:3]","[9:2]","[8:1]","[7:0]"};
		int k = 0;
		for(int m=0; m<9; m++)
		{
			if(m==0||m==4||m==5||m==6||m==7||m==8)
			{
				m_CMBLut.AddString(p[m]);
				m_CMBLut.SetItemData(k,m);
				k++;
			}
		}

		m_pColorFormat.EnableWindow(1);
		char* q[2] = {"MONO8","MONO12"};
		int i[2]   = {3,13};
		for(int m=0; m<2; m++)
		{
			m_pColorFormat.AddString(q[m]);
			m_pColorFormat.SetItemData(m,i[m]);
		}

		m_bAlgEnable = TRUE;
	}
	
	if(pDemoDlg->m_iDevSeries == RS5001_S  || pDemoDlg->m_iDevSeries == RS361_S || pDemoDlg->m_iDevSeries == RS1000_S
	|| pDemoDlg->m_iDevType == RS_A10K_GC7 || pDemoDlg->m_iDevType == RS_A10K_GM7 || pDemoDlg->m_iDevType == RS_A14K_GC8
	|| pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30
	|| pDemoDlg->m_iDevType == RS_A2300_GM50 || pDemoDlg->m_iDevType == RS_A2300_GC50 
	|| pDemoDlg->m_iDevType == RS_A2300_GM60 || pDemoDlg->m_iDevType == RS_A2300_GC60 
	|| pDemoDlg->m_iDevType == RS_A1300_GC60 || pDemoDlg->m_iDevType == RS_A1300_GM60
	|| pDemoDlg->m_iDevType == RS_A1500_GM60 
	|| pDemoDlg->m_iDevType == RS_A363_GM150 || pDemoDlg->m_iDevType == RS_A363_GC150 || pDemoDlg->m_iDevSeries == RS1302_S)
	{
		if(pDemoDlg->m_iDevFW<0x2000)
		{
			m_CMBLut.ResetContent();
			if(pDemoDlg->m_iDevSeries == RS5001_S || pDemoDlg->m_iDevType == RS_A10K_GC7 || pDemoDlg->m_iDevType == RS_A10K_GM7)
			{
				m_CMBLut.AddString("[11:4]");
				m_CMBLut.AddString("[10:3]");
			}
			m_CMBLut.AddString("[9:2]");
			m_CMBLut.AddString("[8:1]");
			m_CMBLut.AddString("[7:0]");
		}
		else if(pDemoDlg->m_iDevFW>=0x2000)
		{
			m_CMBLut.ResetContent();

			char* p[9] = {"[11:0]","[11:2]","[10:1]","[9:0]","[11:4]","[10:3]","[9:2]","[8:1]","[7:0]"};

			int k = 0;
			for(int m=0; m<9; m++)
			{
				if(((pDemoDlg->m_iDevType==RS_A2300_GC50 || pDemoDlg->m_iDevType == RS_A1300_GC60 
				|| pDemoDlg->m_iDevType == RS_A2300_GM50 || pDemoDlg->m_iDevType == RS_A1300_GM60 
				|| pDemoDlg->m_iDevType == RS_A1500_GM60 
				|| pDemoDlg->m_iDevType == RS_A2300_GM60 || pDemoDlg->m_iDevType == RS_A2300_GC60
				|| pDemoDlg->m_iDevType == RS_A363_GM150 || pDemoDlg->m_iDevType == RS_A363_GC150) 
				&& (m==3||m==6||m==7||m==8))
				|| ((pDemoDlg->m_iDevType==RS_A5001_GC14 || pDemoDlg->m_iDevType==RS_A5001_GM14 
				|| pDemoDlg->m_iDevType==RS_A10K_GC7 || pDemoDlg->m_iDevType==RS_A10K_GM7
				|| pDemoDlg->m_iDevType==RS_A1302_GM80 || pDemoDlg->m_iDevType==RS_A1302_GC80 || pDemoDlg->m_iDevType == RS_A301_GM387) 
				&& (m==0||m==4||m==5||m==6||m==7||m==8))
				|| ((pDemoDlg->m_iDevType==RS_A361_GC100 || pDemoDlg->m_iDevType==RS_A361_GM100 
				|| pDemoDlg->m_iDevType==RS_A361_GC60  || pDemoDlg->m_iDevType==RS_A361_GM60) 
				&& (m==3||m==6||m==7||m==8))
				|| ((pDemoDlg->m_iDevType==RS_A14K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30) 
				&& (m==4||m==5||m==6||m==7||m==8))
				)
				{
					m_CMBLut.AddString(p[m]);
					m_CMBLut.SetItemData(k,m);
					k++;
				}
			}
		}

		m_bAlgEnable = TRUE;
		if((pDemoDlg->m_iDevType == RS_A2300_GM50 || pDemoDlg->m_iDevType == RS_A2300_GC50 
		 ||	pDemoDlg->m_iDevType == RS_A2300_GM60 || pDemoDlg->m_iDevType == RS_A2300_GC60
		 || pDemoDlg->m_iDevType == RS_A1300_GC60 || pDemoDlg->m_iDevType == RS_A1300_GM60
		 || pDemoDlg->m_iDevType == RS_A1500_GM60 )
			&&(pDemoDlg->m_iDevFW<0x2000))
		{
			m_bAlgEnable = FALSE;
		}
		/*
		 * 0 : RAW8(LUT);
		 * 1 : RAW10;
		 * 2 : RAW12;
		 * 3 : MONO8;
		 * 4 : RGB24;
		 * 5 : YUV444 UYV;
		 * 6 : YUV422 UYVY;
		 * 7 : YUV422 YUYV;
		 */
		m_pColorFormat.ResetContent();
		if(pDemoDlg->m_iDevFW<0x2000)
		{
			char* p[11] = {"RAW8(LUT)","RAW10","RAW12","MONO8","BGR24","YUV444 UYV","YUV422 UYVY","YUV422 YUYV","RGB24","YUV411 UYYVYY","YUV411 YUYYVY"};

			int k = 0;
			int lMaxVal = pDemoDlg->m_bColor?11:4;

			for(int m=0; m<11; m++)
			{
				if(((pDemoDlg->m_iDevSeries == RS5001_S || pDemoDlg->m_iDevType == RS_A10K_GC7 || pDemoDlg->m_iDevType == RS_A10K_GM7)&& m!=1 && m<lMaxVal)
				 ||((pDemoDlg->m_iDevSeries == RS361_S  || pDemoDlg->m_iDevSeries == RS1000_S) && m!=2 && m<lMaxVal))
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(k,m);
					k++;
				}
			}
		}
		else if(pDemoDlg->m_iDevFW>=0x2000)
		{
			int k = 0;
			if(pDemoDlg->m_iDevType == RS_A2300_GC50 
			|| pDemoDlg->m_iDevType == RS_A2300_GC60
			|| pDemoDlg->m_iDevType == RS_A1300_GC60
			|| pDemoDlg->m_iDevType == RS_A363_GC150)
			{
				/*
				 * 3   : Mono8
				 * 5   : Mono10
				 * 253 : Bayer8
				 * 254 : Bayer10
				 * 40  : BGR8
				 * 21  : RGB8
				 * 44  : YUV444_UYV
				 * 43  : YUV422_UYVY
				 * 42  : YUV411_UYYVYY
				*/
				char* p[9] = {"MONO8","MONO10","BAYER8","BAYER10","BGR24","RGB24","YUV444 UYV","YUV422 UYVY","YUV411 UYYVYY"};
				int i[9]   = {3,5,253,254,40,21,44,43,42};
				for(int m=0; m<9; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A1300_GM60 
				|| pDemoDlg->m_iDevType == RS_A1500_GM60 
				|| pDemoDlg->m_iDevType == RS_A2300_GM50 
				|| pDemoDlg->m_iDevType == RS_A2300_GM60
				|| pDemoDlg->m_iDevType == RS_A363_GM150)
			{
				char* p[2] = {"MONO8","MONO10"};
				int i[2]   = {3,5};
				for(int m=0; m<2; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A5001_GC14 || pDemoDlg->m_iDevType == RS_A10K_GC7)
			{
				char* p[9] = {"MONO8","MONO12","BAYER8","BAYER12","BGR24","RGB24","YUV444 UYV","YUV422 UYVY","YUV411 UYYVYY"};
				int i[9]   = {3,12,0,2,4,8,5,6,9};
				for(int m=0; m<9; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A14K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GC8)
			{
				char* p[2] = {"MONO8","BAYER8"};
				int i[2]   = {3,0};
				for(int m=0; m<2; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30)
			{
				char* p[1] = {"MONO8"};
				int i[1]   = {3};
				for(int m=0; m<1; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A5001_GM14 || pDemoDlg->m_iDevType == RS_A10K_GM7 || pDemoDlg->m_iDevType == RS_A1302_GM80 || pDemoDlg->m_iDevType == RS_A301_GM387)
			{
				char* p[2] = {"MONO8","MONO12"};
				int i[2]   = {3,12};
				for(int m=0; m<2; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A1302_GC80)
			{
				char* p[4] = {"BAYER8","BAYER12","MONO8","MONO12"};
				int i[4]   = {0,2,3,12};
				for(int m=0; m<4; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A361_GC60 || pDemoDlg->m_iDevType == RS_A361_GC100)
			{
				char* p[9] = {"MONO8","MONO10","BAYER8","BAYER10","BGR24","RGB24","YUV444 UYV","YUV422 UYVY","YUV411 UYYVYY"};
				int i[9]   = {3,11,0,1,4,8,5,6,9};
				for(int m=0; m<9; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			else if(pDemoDlg->m_iDevType == RS_A361_GM60 || pDemoDlg->m_iDevType == RS_A361_GM100 
				|| pDemoDlg->m_iDevType == RS_A1000_GM30)
			{
				char* p[2] = {"MONO8","MONO10"};
				int i[2]   = {3,11};
				for(int m=0; m<2; m++)
				{
					m_pColorFormat.AddString(p[m]);
					m_pColorFormat.SetItemData(m,i[m]);
				}
			}
			
			//Test Pattern
			if(pDemoDlg->m_bColor)
			{
				if(pDemoDlg->m_iDevType == RS_A5001_GC14 || pDemoDlg->m_iDevType == RS_A10K_GC7 || pDemoDlg->m_iDevType == RS_A1302_GC80)
				{
					char* p[8] = {"�ر�","����ģ�����ͼ","�Խǻҽ�8bit","�Խǻҽ�12bit","�ƶ��ĶԽǻҽ�8bit","�ƶ��ĶԽǻҽ�12bit","�ƶ��ĶԽǲ�ɫ�ҽ�","ˮƽ��ɫ��"};
					int i[8]   = {0,255,1,3,4,6,7,8};
					for(int m=0; m<8; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
				else if(pDemoDlg->m_iDevType == RS_A14K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30 || pDemoDlg->m_iDevType == RS_A1302_GM80)
				{
					char* p[3] = {"�ر�","�Խǻҽ�8bit","�ƶ��ĶԽǻҽ�8bit"};
					int i[3]   = {0,1,4};
					for(int m=0; m<3; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
				else
				{
					char* p[8] = {"�ر�","����ģ�����ͼ","�Խǻҽ�8bit","�Խǻҽ�10bit","�ƶ��ĶԽǻҽ�8bit","�ƶ��ĶԽǻҽ�10bit","�ƶ��ĶԽǲ�ɫ�ҽ�","ˮƽ��ɫ��"};
					int i[8]   = {0,255,1,2,4,5,7,8};
					for(int m=0; m<8; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
			}
			else
			{
				if(pDemoDlg->m_iDevType == RS_A5001_GM14 || pDemoDlg->m_iDevType == RS_A10K_GM7)
				{
					char* p[6] = {"�ر�","����ģ�����ͼ","�Խǻҽ�8bit","�Խǻҽ�12bit","�ƶ��ĶԽǻҽ�8bit","�ƶ��ĶԽǻҽ�12bit"};
					int i[6]   = {0,255,1,3,4,6};
					for(int m=0; m<6; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
				else if(pDemoDlg->m_iDevType == RS_A1302_GM80 || pDemoDlg->m_iDevType == RS_A301_GM387)
				{
					char* p[4] = {"�ر�","����ģ�����ͼ","�Խǻҽ�8bit","�ƶ��ĶԽǻҽ�8bit"};
					int i[4]   = {0,255,1,4};
					for(int m=0; m<4; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
				else
				{
					char* p[6] = {"�ر�","����ģ�����ͼ","�Խǻҽ�8bit","�Խǻҽ�10bit","�ƶ��ĶԽǻҽ�8bit","�ƶ��ĶԽǻҽ�10bit"};
					int i[6]   = {0,255,1,2,4,5};
					for(int m=0; m<6; m++)
					{
						m_pTestPattern.AddString(p[m]);
						m_pTestPattern.SetItemData(m,i[m]);
					}
				}
			}
		}	
	}

	//HW ALG
	GetDlgItem(IDC_CHK_Enhance)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&(pDemoDlg->m_iDevType != RS_A14K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_EDT_ColorEnhance)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&(pDemoDlg->m_iDevType != RS_A14K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_EDT_HueEnhance)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&(pDemoDlg->m_iDevType != RS_A14K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_BTN_Saturation)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&(pDemoDlg->m_iDevType != RS_A14K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_BTN_Hue)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&(pDemoDlg->m_iDevType != RS_A14K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_CMB_ColorFormat)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_EDT_AWBStartX)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_EDT_AWBStartY)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_EDT_AWBEndX)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_EDT_AWBEndY)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_BTN_AWB)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_BTN_AWBReset)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_EDT_AWBRatioRG)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_EDT_AWBRatioBG)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_BTN_AWBApply)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_bColor);
	GetDlgItem(IDC_CMB_Unit)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_CMB_FilterMode)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_CMB_SharpenMode)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000&&(pDemoDlg->m_iDevType != RS_A12K_GC8)&&(pDemoDlg->m_iDevType != RS_A12K_GM8)&&(pDemoDlg->m_iDevType != RS_A12K_GM30));
	GetDlgItem(IDC_CMB_UserOut)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_CHK_UserOutEnable)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_CHK_UserOutInvert)->EnableWindow(m_bAlgEnable);
	GetDlgItem(IDC_CHK_Gamma)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_EDT_GammaRaw)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_BTN_Gamma)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000);
	GetDlgItem(IDC_CMB_TestPattern)->EnableWindow(m_bAlgEnable&&pDemoDlg->m_iDevFW>=0x2000);

	//RS_A1003 SPEC
	if(pDemoDlg->m_iDevSeries == RS1003_S || pDemoDlg->m_iDevSeries == CM1003_S)
	{
		GetDlgItem(IDC_CHK_Gamma)->EnableWindow(1);
		GetDlgItem(IDC_EDT_GammaRaw)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Gamma)->EnableWindow(1);
		GetDlgItem(IDC_EDT_ADLimitHigh)->EnableWindow(1);
		GetDlgItem(IDC_EDT_ADLimitLow)->EnableWindow(1);
		GetDlgItem(IDC_EDT_ADKneePoint)->EnableWindow(1);
		GetDlgItem(IDC_BTN_ADLimitHigh)->EnableWindow(1);
		GetDlgItem(IDC_BTN_ADLimitLow)->EnableWindow(1);
		GetDlgItem(IDC_CHK_ADLimitManual)->EnableWindow(1);
		GetDlgItem(IDC_BTN_ADKneePoint)->EnableWindow(1);
		GetDlgItem(IDC_SLD_LimitHigh)->EnableWindow(1);
		GetDlgItem(IDC_SLD_LimitLow)->EnableWindow(1);
		GetDlgItem(IDC_SLD_KneePoint)->EnableWindow(1);
		((CSliderCtrl*)GetDlgItem(IDC_SLD_LimitHigh))->SetRange(0,16383); 
		((CSliderCtrl*)GetDlgItem(IDC_SLD_LimitLow))->SetRange(0,16383); 
		((CSliderCtrl*)GetDlgItem(IDC_SLD_KneePoint))->SetRange(0,255); 
		SetTimer(1,1000,NULL);
	}

	if(pDemoDlg->m_iDevSeries == CM1003_S)
	{
		GetDlgItem(IDC_BTN_SoftReset)->EnableWindow(0);
		m_CMBLut.ResetContent();
		m_CMBLut.EnableWindow(0);
		m_pColorFormat.EnableWindow(1);
		m_pLEDEnable.EnableWindow(1);

		char* p[2] = {"MONO8","MONO14"};
		int i[2]   = {1,0};
		for(int m=0; m<2; m++)
		{
			m_pColorFormat.AddString(p[m]);
			m_pColorFormat.SetItemData(m,i[m]);
		}
		m_pTestPattern.EnableWindow(TRUE);

		char* p1[5] = {"FPGA���","����ͼ","ԭʼͼ","ԭʼͼ+ֱ��ͼ����","ԭʼͼ+ֱ��ͼ����+�˲�"};
		int i1[5]   = {0,1,2,3,4};
		for(int m=0; m<5; m++)
		{
			m_pTestPattern.AddString(p1[m]);
			m_pTestPattern.SetItemData(m,i1[m]);
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCOMFpga::OnChangeEDTTrigDelay() 
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_DELAY,m_iTrigDelay);
}

void CCOMFpga::OnChangeEDTTrigInterval() 
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGERDELAY,m_iTrigInterval);
}

void CCOMFpga::OnChangeEDTTrigWidth() 
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_PULSEWIDTH,m_iTrigWidth);
}

void CCOMFpga::OnBnClickedChkFlash()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_STROBEOUT,m_bFlashOut);
}

void CCOMFpga::OnBnClickedChkDefectremove()
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_NOISEREMOVE,((CButton*)GetDlgItem(IDC_CHK_DefectRemove))->GetCheck());
}

void CCOMFpga::OnDestroy()
{
	CDialog::OnDestroy();
	KillTimer(0);
	// TODO: Add your message handler code here
}

void CCOMFpga::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent==0)
	{
		if(pDemoDlg->m_iDevType == RS_A1300_GM60 || pDemoDlg->m_iDevType == RS_A1300_GC60
			|| pDemoDlg->m_iDevType == RS_A1500_GM60 
			|| pDemoDlg->m_iDevType == RS_A2300_GM50 || pDemoDlg->m_iDevType == RS_A2300_GC50
			|| pDemoDlg->m_iDevType == RS_A2300_GM60 || pDemoDlg->m_iDevType == RS_A2300_GC60
			|| pDemoDlg->m_iDevType == RS_A5001_GM14 || pDemoDlg->m_iDevType == RS_A5001_GC14
			|| pDemoDlg->m_iDevType == RS_A1400_GM60 || pDemoDlg->m_iDevType == RS_A1400_GC60 
			|| pDemoDlg->m_iDevType == RS_A1500_GM60 || pDemoDlg->m_iDevType == RS_A2001_GM60
			|| pDemoDlg->m_iDevType == RS_A10K_GC7   || pDemoDlg->m_iDevType == RS_A10K_GM7	 
			|| pDemoDlg->m_iDevType == RS_A361_GC60  || pDemoDlg->m_iDevType == RS_A361_GM60
			|| pDemoDlg->m_iDevType == RS_A361_GC100 || pDemoDlg->m_iDevType == RS_A361_GM100
			|| pDemoDlg->m_iDevType == RS_A1000_GM30
			|| pDemoDlg->m_iDevType == RS_A363_GM150 || pDemoDlg->m_iDevType == RS_A363_GC150
			|| pDemoDlg->m_iDevType == RS_A14K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType == RS_A12K_GM30)
		{
			int l_iTemp		= MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCCAP_TEMPERATURE);
			m_sTemperature  = (l_iTemp>>8)&0x1?"-":"" + Int2Cstr(l_iTemp&0xff);
			GetDlgItem(IDC_EDT_Temperature)->SetWindowText(m_sTemperature);
		}
	}
	else if(nIDEvent==1)
	{
		if(!m_bADLimit)
		{
			m_iADLimitLow  = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITLOW);
			m_iADLimitHigh = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITHIGH);
			CString lStr;
			lStr.Format("%d",m_iADLimitLow);
			GetDlgItem(IDC_EDT_ADLimitLow)->SetWindowText(lStr);
			lStr.Format("%d",m_iADLimitHigh);
			GetDlgItem(IDC_EDT_ADLimitHigh)->SetWindowText(lStr);
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CCOMFpga::OnCbnSelchangeCmbTrigpolarity()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGGER_POLARITY,m_iTrigPolarity);
}

void CCOMFpga::OnEnChangeEdtFlashdelay()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASHDELAY,m_iFlashDelay);
}

void CCOMFpga::OnCbnSelchangeCmbFlashpolarity()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASH_POLARITY,m_iFlashPolarity);
}

void CCOMFpga::OnEnChangeEdtFlashwidth()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FLASHWIDTH,m_iFlashWidth);
}

void CCOMFpga::OnBnClickedChkTemperature()
{
	UpdateData(TRUE);
	if(m_bTimer)
	{
		SetTimer(0,2000,NULL);
	}
	else
	{
		KillTimer(0);
	}
}

void CCOMFpga::OnBnClickedBtnAwb()
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_REDGAIN,100);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GREENGAIN,100);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_BLUEGAIN,100);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBONCE,1);
	Sleep(500);
	m_iAWBRatioRG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIORG);
	m_iAWBRatioBG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIOBG);
	UpdateData(FALSE);
}

void CCOMFpga::OnCbnSelchangeCmbColorformat()
{
	int lValue = m_pColorFormat.GetItemData( m_pColorFormat.GetCurSel());
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IMAGEDATA,lValue);
}

void CCOMFpga::OnCbnSelchangeCmbSofttrig()
{
	UpdateData(TRUE);
}

BOOL CCOMFpga::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_ESCAPE) 
	{ 
		return TRUE; 
	} 

	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_RETURN) 
	{ 
		return TRUE; 
	} 
	else 
	{ 
		return CDialog::PreTranslateMessage(pMsg); 
	}
}

void CCOMFpga::OnCbnSelchangeCmbFiltermode()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_DENOISING,m_iFilterMode);
}

void CCOMFpga::OnCbnSelchangeCmbSharpenmode()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SHARPNESS,m_iShapenMode);
}

void CCOMFpga::OnCbnSelchangeCmbUnit()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IOUNIT,m_iUnit);
}

void CCOMFpga::OnCbnSelchangeCmbUserout()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTSELECT,m_iUserOutSelect);
}

void CCOMFpga::OnBnClickedChkUseroutenable()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTENABLE,m_bUserOutEnable);
}

void CCOMFpga::OnBnClickedChkUseroutinvert()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_USEROUTINVERT,m_bUserOutInvert);
}

void CCOMFpga::OnBnClickedBtnAwbreset()
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRESET,1);
	m_iAWBRatioRG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIORG);
	m_iAWBRatioBG = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIOBG);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedChkEnhance()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ENHANCEENABLE,m_bEnhanceEnable);
}

void CCOMFpga::OnBnClickedChkGamma()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GAMMAENABLE,m_bGammaEnable);
}

void CCOMFpga::OnBnClickedBtnTrignum()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_TRIGPICNUM,m_iTrigNumber);
}

void CCOMFpga::OnBnClickedBtnSkipnum()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_FRAMESKIP,m_iSkipFrame);
}

void CCOMFpga::OnBnClickedBtnMaxfps()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FPSMAX,m_iCapFpsMax);
}

void CCOMFpga::OnBnClickedBtnSaturation()
{
	UpdateData(TRUE);
	if(m_iColorEnhance>511) m_iColorEnhance = 511;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_COLORENHANCE,m_iColorEnhance);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnHue()
{
	UpdateData(TRUE);
	if(m_iHueEnhance<2) m_iHueEnhance = 2;
	if(m_iHueEnhance>62) m_iHueEnhance = 62;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_HUEENHANCE,m_iHueEnhance);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnGamma()
{
	UpdateData(TRUE);
	if(m_iGamma<5) m_iGamma = 5;
	if(m_iGamma>25) m_iGamma = 25;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_GAMMARAW,m_iGamma);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnAwbapply()
{
	UpdateData(TRUE);
	if(m_iAWBStartX>m_iAWBEndX)
	{
		m_iAWBStartX = m_iAWBEndX;
	}
	if(m_iAWBStartY>m_iAWBEndY)
	{
		m_iAWBStartY = m_iAWBEndY;
	}
	if(m_iAWBEndX>pDemoDlg->m_iWidthMax-1)
	{
		m_iAWBEndX = pDemoDlg->m_iWidthMax-1;
	}
	if(m_iAWBEndX<m_iAWBStartX)
	{
		m_iAWBEndX = m_iAWBStartX;
	}
	if(m_iAWBEndY>pDemoDlg->m_iHeightMax-1)
	{
		m_iAWBEndY = pDemoDlg->m_iHeightMax-1;
	}
	if(m_iAWBEndY<m_iAWBStartY)
	{
		m_iAWBEndY = m_iAWBStartY;
	}
	if(m_iAWBRatioRG>0xff)
	{
		m_iAWBRatioRG = 0xff;
	}
	if(m_iAWBRatioBG>0xff)
	{
		m_iAWBRatioBG = 0xff;
	}
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSSTARTX,m_iAWBStartX);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSSTARTY,m_iAWBStartY);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSENDX,m_iAWBEndX);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBPOSENDY,m_iAWBEndY);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIORG,m_iAWBRatioRG);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_AWBRATIOBG,m_iAWBRatioBG);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnBright()
{
	UpdateData(TRUE);
	if(m_iBright<1)  m_iBright = 1;
	if(m_iBright>96) m_iBright = 96;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SBRIGHTNESS,m_iBright);
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnContrast()
{
	UpdateData(TRUE);
	if(m_iContrast<1)  m_iContrast = 1;
	if(m_iContrast>96) m_iContrast = 96;
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_SCONTRAST,m_iContrast);
	UpdateData(FALSE);
}

void CCOMFpga::OnCbnSelchangeCmbTestpattern()
{
	int lValue = m_pTestPattern.GetItemData( m_pTestPattern.GetCurSel());
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_TESTPATTERN,lValue);
	Sleep(200);
	m_iColorFormat		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_IMAGEDATA);
	for ( int i = 0; i < m_pColorFormat.GetCount(); i++ )
	{
		DWORD_PTR lData = m_pColorFormat.GetItemData( i );
		if ( lData == m_iColorFormat )
		{
			m_pColorFormat.SetCurSel( i );
			break;
		}
	}
}

void CCOMFpga::OnBnClickedBtnAdlimithigh()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITHIGH,m_iADLimitHigh);
	m_iADLimitHigh = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITHIGH);
	m_iLimitHigh = m_iADLimitHigh;
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedBtnAdlimitlow()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITLOW,m_iADLimitLow);
	m_iADLimitLow = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITLOW);
	m_iLimitLow = m_iADLimitLow;
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedChkAdlimitmanual()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITENABLE,m_bADLimit);
	if(!m_bADLimit)
	{
		SetTimer(1,1000,NULL);
	}
	else
	{
		KillTimer(1);
	}
}

void CCOMFpga::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	switch(pScrollBar->GetDlgCtrlID())
	{
	case IDC_SLD_LimitLow:
		UpdateData(TRUE);
		m_iADLimitLow = m_iLimitLow;
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITLOW,m_iADLimitLow);
		UpdateData(FALSE);
		break;
	case IDC_SLD_LimitHigh:
		UpdateData(TRUE);
		m_iADLimitHigh = m_iLimitHigh;
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADLIMITHIGH,m_iADLimitHigh);
		UpdateData(FALSE);
		break;
	case IDC_SLD_KneePoint:
		UpdateData(TRUE);
		m_iADKneePoint = m_iKneePoint;
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADKNEEPOINT,m_iADKneePoint);
		UpdateData(FALSE);
		break;
	}
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CCOMFpga::OnBnClickedBtnAdkneepoint()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADKNEEPOINT,m_iADKneePoint);
	m_iADKneePoint = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_ADKNEEPOINT);
	m_iKneePoint = m_iADKneePoint;
	UpdateData(FALSE);
}

void CCOMFpga::OnBnClickedChkFpscontrol()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FPSMAXENABLE,m_bFpsControl);
}

void CCOMFpga::OnCbnSelchangeCmbLed()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_LEDCONTROL,m_iLedEnable);
}