#pragma once
#include "afxwin.h"


// CCOMSave dialog

class CCOMSave : public CDialog
{
	DECLARE_DYNAMIC(CCOMSave)

public:
	CCOMSave(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCOMSave();

// Dialog Data
	//{{AFX_DATA(CCOMSave)
	enum { IDD = IDD_DLG_SAV };
	int m_iMulti;
	CString GetSelFolder();
	COMPVARS		*m_Compressor;	//AVI������
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CCOMSave)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CCOMSave)
	afx_msg void OnSelchangeCmbPicType();
	afx_msg void OnBnClickedBtnSingle();
	afx_msg void OnBnClickedBtnMultiple();
	afx_msg void OnBTNCoder();
	afx_msg void OnBTNAVISave();
	afx_msg void OnBTNAVIPause();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void MultiFlag(int lIndex); //��֡��ͼ��Ŀָʾ
	void CompressFlag(int lIndex); //AVI¼��֡Ŀָʾ
	BOOL GetCompressorName(COMPVARS *aCOMPVARS, CString &aName);
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CComboBox m_cPicType;
public:
	afx_msg void OnBnClickedBtnSelectpath();
};
