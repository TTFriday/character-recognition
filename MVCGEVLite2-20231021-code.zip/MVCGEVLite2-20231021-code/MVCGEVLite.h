// MVCGEVLite.h : main header file for the MVCGEVLite application
//

#if !defined(AFX_MVCGEVLite_H__FD6B8851_EDAC_4C14_A203_B4EA1C9102A9__INCLUDED_)
#define AFX_MVCGEVLite_H__FD6B8851_EDAC_4C14_A203_B4EA1C9102A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

//add by peter 20210302
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>                
#include <opencv2/highgui/highgui.hpp>    
#include <opencv2/imgproc/imgproc.hpp> 

#ifdef _DEBUG  
#pragma comment(lib, "opencv_world410d.lib")

#else   
#pragma comment(lib, "opencv_world410.lib")
#endif  

using namespace cv;
//add by peter 20210302

/////////////////////////////////////////////////////////////////////////////
// CMVCGEVLiteApp:
// See MVCGEVLite.cpp for the implementation of this class
//

class CMVCGEVLiteApp : public CWinApp
{
public:
	CMVCGEVLiteApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMVCGEVLiteApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMVCGEVLiteApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MVCGEVLite_H__FD6B8851_EDAC_4C14_A203_B4EA1C9102A9__INCLUDED_)
