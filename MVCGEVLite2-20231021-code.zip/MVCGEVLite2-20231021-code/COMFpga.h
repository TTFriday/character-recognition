#include "afxwin.h"
#if !defined(AFX_COMFPGA_H__38C59348_058C_4986_B222_64E88A935413__INCLUDED_)
#define AFX_COMFPGA_H__38C59348_058C_4986_B222_64E88A935413__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// COMFpga.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCOMFpga dialog

class CCOMFpga : public CDialog
{
// Construction
public:
	CCOMFpga(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CCOMFpga)
	enum { IDD = IDD_DLG_FPGA };
	CComboBox	m_CMBLut;
	int		m_iDebouce;
	int		m_iTrigNumber;
	UINT	m_iTrigDelay;
	UINT	m_iTrigInterval;
	UINT	m_iTrigWidth;
	//}}AFX_DATA

	BOOL m_bAlgEnable;
	void InitParamCOMFpga();	//��ȡ����

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCOMFpga)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCOMFpga)
	afx_msg void OnBTNSoftTrigger();
	afx_msg void OnBTNSoftReset();
	afx_msg void OnSelchangeCMBBITLut();
	afx_msg void OnChangeEDTDebounceWidth();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnChangeEDTTrigDelay();
	afx_msg void OnChangeEDTTrigInterval();
	afx_msg void OnChangeEDTTrigWidth();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg void OnBnClickedChkFlash();
public:
	afx_msg void OnBnClickedChkDefectremove();
public:
	int m_iBright;
public:
	int m_iContrast;
public:
	CString m_sTemperature;
public:
	afx_msg void OnDestroy();
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
public:
	UINT m_iFlashDelay;
public:
	UINT m_iFlashWidth;
public:
	int m_iTrigPolarity;
public:
	int m_iFlashPolarity;
public:
	BOOL m_bFlashOut;
public:
	afx_msg void OnCbnSelchangeCmbTrigpolarity();
public:
	afx_msg void OnEnChangeEdtFlashdelay();
public:
	afx_msg void OnCbnSelchangeCmbFlashpolarity();
public:
	afx_msg void OnEnChangeEdtFlashwidth();
	BOOL m_bTimer;
	afx_msg void OnBnClickedChkTemperature();
	int m_iColorEnhance;
	int m_iColorFormat;
	int m_iAWBStartX;
	int m_iAWBStartY;
	int m_iAWBEndX;
	int m_iAWBEndY;
	afx_msg void OnBnClickedBtnAwb();
	afx_msg void OnCbnSelchangeCmbColorformat();
	afx_msg void OnCbnSelchangeCmbBayerformat();
public:
	CComboBox m_pColorFormat;
public:
	int m_iSkipFrame;
public:
	int m_iSoftTrigMode;
public:
	afx_msg void OnCbnSelchangeCmbSofttrig();
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	int m_iUnit;
public:
	int m_iFilterMode;
public:
	afx_msg void OnCbnSelchangeCmbFiltermode();
public:
	afx_msg void OnCbnSelchangeCmbUnit();
public:
	afx_msg void OnCbnSelchangeCmbUserout();
public:
	afx_msg void OnBnClickedChkUseroutenable();
public:
	afx_msg void OnBnClickedChkUseroutinvert();
public:
	int m_iUserOutSelect;
public:
	BOOL m_bUserOutEnable;
public:
	BOOL m_bUserOutInvert;
public:
	int m_iHueEnhance;
public:
	BOOL m_bEnhanceEnable;
public:
	afx_msg void OnBnClickedBtnAwbreset();
public:
	afx_msg void OnBnClickedChkEnhance();
public:
	afx_msg void OnCbnSelchangeCmbSharpenmode();
public:
	int m_iShapenMode;
public:
	int m_iCapFpsMax;
public:
	int m_iAWBRatioRG;
	int m_iAWBRatioBG;
	BOOL m_bGammaEnable;
	int m_iGamma;
	afx_msg void OnBnClickedChkGamma();
public:
	afx_msg void OnBnClickedBtnTrignum();
public:
	afx_msg void OnBnClickedBtnSkipnum();
public:
	afx_msg void OnBnClickedBtnMaxfps();
public:
	afx_msg void OnBnClickedBtnSaturation();
public:
	afx_msg void OnBnClickedBtnHue();
public:
	afx_msg void OnBnClickedBtnGamma();
public:
	afx_msg void OnBnClickedBtnAwbapply();
public:
	afx_msg void OnBnClickedBtnBright();
public:
	afx_msg void OnBnClickedBtnContrast();
public:
	CComboBox m_pTestPattern;
public:
	afx_msg void OnCbnSelchangeCmbTestpattern();
public:
	int m_iTestPattern;
public:
	afx_msg void OnBnClickedBtnTest();
public:
	int m_iADLimitHigh;
public:
	int m_iADLimitLow;
public:
	BOOL m_bADLimit;
public:
	afx_msg void OnBnClickedBtnAdlimithigh();
public:
	afx_msg void OnBnClickedBtnAdlimitlow();
public:
	afx_msg void OnBnClickedChkAdlimitmanual();
public:
	int m_iLimitLow;
public:
	int m_iLimitHigh;
public:
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
public:
	int m_iADKneePoint;
public:
	int m_iKneePoint;
public:
	afx_msg void OnBnClickedBtnAdkneepoint();
public:
	BOOL m_bFpsControl;
public:
	afx_msg void OnBnClickedChkFpscontrol();
	CComboBox m_pLEDEnable;
	afx_msg void OnCbnSelchangeCmbLed();
	int m_iLedEnable;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMFPGA_H__38C59348_058C_4986_B222_64E88A935413__INCLUDED_)
