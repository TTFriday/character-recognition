// COMCam.cpp : implementation file
//

#include "stdafx.h"
#include "MVCGEVLite.h"
#include "MVCGEVLiteDlg.h"
#include "COMCam.h"

extern CMVCGEVLiteDlg *pDemoDlg; //��������

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCOMCam dialog


CCOMCam::CCOMCam(CWnd* pParent /*=NULL*/)
	: CDialog(CCOMCam::IDD, pParent)
	, m_iExpAbs(0)
	, m_bIrisEnable(FALSE)
	, m_bFocusEnable(FALSE)
	, m_iIris(0)
	, m_iFocus(0)
{
	//{{AFX_DATA_INIT(CCOMCam)
	m_iAGain = 0;
	m_iDGain = 0;
	m_iExp = 0;
	m_iXOffset = 0;
	m_iYOffset = 0;
	m_iWidth = 0;
	m_iHeight = 0;
	//}}AFX_DATA_INIT
}


void CCOMCam::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCOMCam)
	DDX_Control(pDX, IDC_CMB_HDR, m_CMBHdr);
	DDX_Control(pDX, IDC_CHK_FlipUD, m_CHKFlipUD);
	DDX_Control(pDX, IDC_CHK_FlipLR, m_CHKFlipLR);
	DDX_Control(pDX, IDC_CHK_CLAMP, m_CHKClamp);
	DDX_Control(pDX, IDC_CMB_WorkMode, m_CMBShutterType);
	DDX_Control(pDX, IDC_SLD_Exp, m_SLDExp);
	DDX_Control(pDX, IDC_SLD_DGain, m_SLDDGain);
	DDX_Control(pDX, IDC_SLD_AGain, m_SLDAGain);
	DDX_Text(pDX, IDC_EDT_AGain, m_iAGain);
	DDX_Text(pDX, IDC_EDT_DGain, m_iDGain);
	DDX_Text(pDX, IDC_EDT_Exp, m_iExp);
	DDX_Text(pDX, IDC_EDT_XOffset, m_iXOffset);
	DDX_Text(pDX, IDC_EDT_YOffset, m_iYOffset);
	DDX_Text(pDX, IDC_EDT_Width, m_iWidth);
	DDX_Text(pDX, IDC_EDT_Height, m_iHeight);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CHK_AEC, m_CHKAEC);
	DDX_Control(pDX, IDC_CHK_AGC, m_CHKAGC);
	DDX_Control(pDX, IDC_SLD_ExpAbs, m_SLDExpAbs);
	DDX_Text(pDX, IDC_EDT_ExpAbs, m_iExpAbs);
	DDX_Check(pDX, IDC_CHK_Iris, m_bIrisEnable);
	DDX_Check(pDX, IDC_CHK_Focus, m_bFocusEnable);
	DDX_Control(pDX, IDC_SLD_Iris, m_SLDIris);
	DDX_Control(pDX, IDC_SLD_Focus, m_SLDFocus);
	DDX_Text(pDX, IDC_EDT_Iris, m_iIris);
	DDX_Text(pDX, IDC_EDT_Focus, m_iFocus);
}


BEGIN_MESSAGE_MAP(CCOMCam, CDialog)
	//{{AFX_MSG_MAP(CCOMCam)
	ON_WM_SHOWWINDOW()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_CHK_CLAMP, OnChkClamp)
	ON_BN_CLICKED(IDC_CHK_FlipLR, OnCHKFlipLR)
	ON_BN_CLICKED(IDC_CHK_FlipUD, OnCHKFlipUD)
	ON_CBN_SELCHANGE(IDC_CMB_WorkMode, OnSelchangeCMBWorkMode)
	ON_BN_CLICKED(IDC_BTN_SIZE, OnBtnSize)
	ON_CBN_SELCHANGE(IDC_CMB_HDR, OnSelchangeCmbHdr)
	ON_BN_CLICKED(IDC_CHK_AEC, OnBnClickedChkAec)
	ON_BN_CLICKED(IDC_CHK_AGC, OnBnClickedChkAgc)	
	ON_BN_CLICKED(IDC_BTN_AGAIN, OnBnClickedBtnAgain)
	ON_BN_CLICKED(IDC_BTN_DGain, OnBnClickedBtnDgain)
	ON_BN_CLICKED(IDC_BTN_Exp, OnBnClickedBtnExp)
	ON_BN_CLICKED(IDC_BTN_ExpAbs, OnBnClickedBtnExpabs)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHK_Iris, &CCOMCam::OnBnClickedChkIris)
	ON_BN_CLICKED(IDC_BTN_Iris, &CCOMCam::OnBnClickedBtnIris)
	ON_BN_CLICKED(IDC_CHK_Focus, &CCOMCam::OnBnClickedChkFocus)
	ON_BN_CLICKED(IDC_BTN_Focus, &CCOMCam::OnBnClickedBtnFocus)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCOMCam message handlers

void CCOMCam::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	InitParamCOMCamera();
}


void CCOMCam::InitParamCOMCamera()
{
	m_iAGain		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_OUTGAIN);
	m_iDGain		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_DACGAIN);
	m_iExp			= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_INTTIME);
	m_iExpAbs		= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_EXPOSURETIME);

	GetDlgItem(IDC_EDT_AGainRange)->SetWindowText("("+Int2Cstr(pDemoDlg->m_iAGainMin)+"-"+Int2Cstr(pDemoDlg->m_iAGainMax)+")");
	GetDlgItem(IDC_EDT_DGainRange)->SetWindowText("("+Int2Cstr(pDemoDlg->m_iDGainMin)+"-"+Int2Cstr(pDemoDlg->m_iDGainMax)+")");
	GetDlgItem(IDC_EDT_ExpRange)->SetWindowText("("+Int2Cstr(pDemoDlg->m_iExpMin)+"-"+Int2Cstr(pDemoDlg->m_iExpMax)+")");

	//Sliders
	m_SLDAGain.SetRange(pDemoDlg->m_iAGainMin,pDemoDlg->m_iAGainMax); 
	m_SLDDGain.SetRange(pDemoDlg->m_iDGainMin,pDemoDlg->m_iDGainMax);
	m_SLDExp.SetRange(pDemoDlg->m_iExpMin,pDemoDlg->m_iExpMax);
	m_SLDExpAbs.SetRange(0,0x4fffff);

	m_SLDAGain.SetPos(m_iAGain);
	m_SLDDGain.SetPos(m_iDGain);
	m_SLDExpAbs.SetPos(m_iExpAbs);
	m_SLDExp.SetPos(m_iExp);

	m_CMBShutterType.SetCurSel(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_SHUTTERTYPE));

	m_iWidth	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_WIDTH);
	m_iHeight	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_HEIGHT);

	if(pDemoDlg->m_iDevSeries == MV10K_S || pDemoDlg->m_iDevSeries == MV1200_S || pDemoDlg->m_iDevSeries == RS1003_S)
	{
		GetDlgItem(IDC_EDT_XOffset)->EnableWindow(0);
		GetDlgItem(IDC_EDT_YOffset)->EnableWindow(0);
		GetDlgItem(IDC_CHK_FlipLR)->EnableWindow(0);
		GetDlgItem(IDC_CHK_FlipUD)->EnableWindow(0);
	}
	else
	{
		m_iXOffset	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORXOFFSET);
		m_iYOffset	= MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORYOFFSET);
		m_CHKFlipLR.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_COLFLIP));
		m_CHKFlipUD.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_MIRROR));
		GetDlgItem(IDC_CHK_FlipLR)->EnableWindow(pDemoDlg->m_iDevSeries != RS1000_S);
	}

	if(pDemoDlg->m_iDevSeries == MV1300_S || pDemoDlg->m_iDevSeries == MV2300_S || pDemoDlg->m_iDevSeries == MV500_S)
	{
		GetDlgItem(IDC_CMB_HDR)->EnableWindow(1);
		GetDlgItem(IDC_CHK_CLAMP)->EnableWindow(1);
		m_CHKClamp.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_BLACKLEVEL));
		m_CMBHdr.SetCurSel(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_HDR));
	}

	if(pDemoDlg->m_iDevSeries == MV1200_S || pDemoDlg->m_iDevSeries == RS361_S)
	{
		m_CHKAEC.EnableWindow(1);
		m_CHKAGC.EnableWindow(1);
		m_CHKAEC.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_AUTOAEC));
		m_CHKAGC.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_AUTOAGC));
	}

	if(pDemoDlg->m_iDevSeries == RS1003_S || pDemoDlg->m_iDevSeries == CM1003_S)
	{
		m_CHKFlipLR.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_COLFLIP));
		m_CHKFlipUD.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_MIRROR));
	}

	if(pDemoDlg->m_bRosa && pDemoDlg->m_iDevFW>=0x2000)
	{
		GetDlgItem(IDC_EDT_ExpAbs)->EnableWindow(1);
		GetDlgItem(IDC_BTN_ExpAbs)->EnableWindow(1);
		GetDlgItem(IDC_SLD_ExpAbs)->EnableWindow(1);
	}

	if(pDemoDlg->m_iDevSeries == HK2400_S)
	{
		GetDlgItem(IDC_CHK_Iris)->EnableWindow(1);
		GetDlgItem(IDC_CHK_Focus)->EnableWindow(1);
		GetDlgItem(IDC_EDT_Iris)->EnableWindow(1);
		GetDlgItem(IDC_EDT_Focus)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Iris)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Focus)->EnableWindow(1);
		GetDlgItem(IDC_SLD_Iris)->EnableWindow(1);
		GetDlgItem(IDC_SLD_Focus)->EnableWindow(1);
		m_bIrisEnable = MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_IRISPOSITIONENABLE);
		m_bFocusEnable = MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_FOCUSPOSITIONENABLE);
		m_iIris = MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_IRISPOSITION);
		m_iFocus = MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_FOCUSPOSITION);
		m_SLDIris.SetRange(900,2100); 
		m_SLDFocus.SetRange(900,2100);
		m_SLDIris.SetPos(m_iIris);
		m_SLDFocus.SetPos(m_iFocus);
	}

	if(pDemoDlg->m_iDevType == RS_A14K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GC8 || pDemoDlg->m_iDevType == RS_A12K_GM8 || pDemoDlg->m_iDevType==RS_A12K_GM30)
	{
		GetDlgItem(IDC_CHK_FlipLR)->EnableWindow(1);
		GetDlgItem(IDC_CHK_FlipUD)->EnableWindow(1);
		m_CHKFlipLR.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_COLFLIP));
		m_CHKFlipUD.SetCheck(MVC_GetParameter(pDemoDlg->m_iDevIndex, MVCADJ_MIRROR));
		if (pDemoDlg->m_iDevType==RS_A12K_GM8||pDemoDlg->m_iDevType==RS_A12K_GC8||pDemoDlg->m_iDevType==RS_A12K_GM30)
		{
			m_SLDExpAbs.SetRange(50,120000);
			GetDlgItem(IDC_EDT_Width)->EnableWindow(0);
			GetDlgItem(IDC_EDT_Height)->EnableWindow(0);
			GetDlgItem(IDC_BTN_SIZE)->EnableWindow(0);
		}
	}

	UpdateData(FALSE);
}

void CCOMCam::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CString str;
	CString lStr;
	switch(pScrollBar->GetDlgCtrlID())
	{
	case IDC_SLD_AGain:
		m_iAGain=m_SLDAGain.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_OUTGAIN,m_iAGain);
		break;
	case IDC_SLD_DGain:
		m_iDGain = m_SLDDGain.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_DACGAIN,m_iDGain);
		break;
	case IDC_SLD_Exp:
		m_iExp = m_SLDExp.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_INTTIME,m_iExp);
		m_iExpAbs = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_EXPOSURETIME);
		break;
	case IDC_SLD_ExpAbs:
		m_iExpAbs = m_SLDExpAbs.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_EXPOSURETIME,m_iExpAbs);
		m_iExp = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_INTTIME);
		break;
	case IDC_SLD_Iris:
		m_iIris = m_SLDIris.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_IRISPOSITION,m_iIris);
		break;
	case IDC_SLD_Focus:
		m_iFocus = m_SLDFocus.GetPos();
		MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FOCUSPOSITION,m_iFocus);
		break;
	}
	UpdateData(FALSE);
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CCOMCam::OnChkClamp() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex, MVCADJ_BLACKLEVEL, m_CHKClamp.GetCheck());
}

void CCOMCam::OnCHKFlipLR() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex, MVCADJ_COLFLIP, m_CHKFlipLR.GetCheck());
}

void CCOMCam::OnCHKFlipUD() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex, MVCADJ_MIRROR, m_CHKFlipUD.GetCheck());
}

void CCOMCam::OnSelchangeCMBWorkMode() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex, MVCADJ_SHUTTERTYPE, m_CMBShutterType.GetCurSel());
}

void CCOMCam::OnBtnSize() 
{
	if(pDemoDlg->m_bCapture)
	{
		MVC_DisableCapture(pDemoDlg->m_iDevIndex);
	}
	UpdateData(TRUE);
	if(m_iWidth<pDemoDlg->m_iWidthMin)
	{
		m_iWidth = pDemoDlg->m_iWidthMin;
	}
	if(m_iHeight<pDemoDlg->m_iHeightMin)
	{
		m_iHeight = pDemoDlg->m_iHeightMin;
	}
	if(m_iWidth>pDemoDlg->m_iWidthMax)
	{
		m_iWidth = pDemoDlg->m_iWidthMax;
	}
	if(m_iHeight>pDemoDlg->m_iHeightMax)
	{
		m_iHeight = pDemoDlg->m_iHeightMax;
	}
	if(m_iXOffset+m_iWidth>pDemoDlg->m_iWidthMax) 
	{
		m_iXOffset = pDemoDlg->m_iWidthMax - m_iWidth;
	}
	if(m_iYOffset+m_iHeight>pDemoDlg->m_iHeightMax) 
	{
		m_iYOffset = pDemoDlg->m_iHeightMax - m_iHeight;
	}
	UpdateData(FALSE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORXOFFSET,0);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORYOFFSET,0);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORWIDTH,m_iWidth);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORHEIGHT,m_iHeight);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORXOFFSET,m_iXOffset);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_SENSORYOFFSET,m_iYOffset);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_WIDTH,m_iWidth);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_HEIGHT,m_iHeight);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_XOFFSET,0);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_YOFFSET,0);
	m_iWidth  = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_WIDTH);
	m_iHeight = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_HEIGHT);
	pDemoDlg->m_iImgWidth = m_iWidth;
	pDemoDlg->m_iImgHeight = m_iHeight;
	if(pDemoDlg->m_bCapture)
	{
		MVC_EnableCapture(pDemoDlg->m_iDevIndex);
	}
}

void CCOMCam::OnSelchangeCmbHdr() 
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex, MVCADJ_HDR, m_CMBHdr.GetCurSel());
}

void CCOMCam::OnBnClickedChkAec()
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_AUTOAEC,m_CHKAEC.GetCheck());
}

void CCOMCam::OnBnClickedChkAgc()
{
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_AUTOAGC,m_CHKAGC.GetCheck());
}

BOOL CCOMCam::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_ESCAPE) 
	{ 
		return TRUE; 
	} 

	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_RETURN) 
	{ 
		return TRUE; 
	} 
	else 
	{ 
		return CDialog::PreTranslateMessage(pMsg); 
	}
}

void CCOMCam::OnBnClickedBtnAgain()
{
	UpdateData(TRUE);
	if(m_iAGain>pDemoDlg->m_iAGainMax) m_iAGain = pDemoDlg->m_iAGainMax;
	if(m_iAGain<pDemoDlg->m_iAGainMin) m_iAGain = pDemoDlg->m_iAGainMin;
	UpdateData(FALSE);
	m_SLDAGain.SetPos(m_iAGain);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_OUTGAIN,m_iAGain);
}

void CCOMCam::OnBnClickedBtnDgain()
{
	UpdateData(TRUE);
	if(m_iDGain>pDemoDlg->m_iDGainMax) m_iDGain = pDemoDlg->m_iDGainMax;
	if(m_iDGain<pDemoDlg->m_iDGainMin) m_iDGain = pDemoDlg->m_iDGainMin;
	UpdateData(FALSE);
	m_SLDDGain.SetPos(m_iDGain);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_DACGAIN,m_iDGain);
}

void CCOMCam::OnBnClickedBtnExp()
{
	UpdateData(TRUE);
	if(m_iExp>pDemoDlg->m_iExpMax) m_iExp = pDemoDlg->m_iExpMax;
	if(m_iExp<pDemoDlg->m_iExpMin) m_iExp = pDemoDlg->m_iExpMin;
	m_SLDExp.SetPos(m_iExp);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_INTTIME,m_iExp);
	m_iExpAbs = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCCAP_EXPOSURETIME);
	m_SLDExpAbs.SetPos(m_iExpAbs);
	UpdateData(FALSE);
}

void CCOMCam::OnBnClickedBtnExpabs()
{
	UpdateData(TRUE);
	if (pDemoDlg->m_iDevType==RS_A12K_GM8||pDemoDlg->m_iDevType==RS_A12K_GC8 ||pDemoDlg->m_iDevType==RS_A12K_GM30)
	{
		if (m_iExpAbs<50)
		{
			m_iExpAbs=50;
		}
		if (m_iExpAbs>120000)
		{
			m_iExpAbs=120000;
		}
	}
	m_SLDExpAbs.SetPos(m_iExpAbs);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCCAP_EXPOSURETIME,m_iExpAbs);
	m_iExp = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_INTTIME);
	m_SLDExp.SetPos(m_iExp);
	UpdateData(FALSE);
}

void CCOMCam::OnBnClickedChkIris()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_IRISPOSITIONENABLE,m_bIrisEnable);
}

void CCOMCam::OnBnClickedBtnIris()
{
	UpdateData(TRUE);
	if(m_iIris>2100) m_iIris = 2100;
	if(m_iIris<900) m_iIris = 900;
	UpdateData(FALSE);
	m_SLDIris.SetPos(m_iIris);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_IRISPOSITION,m_iIris);
}

void CCOMCam::OnBnClickedChkFocus()
{
	UpdateData(TRUE);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FOCUSPOSITIONENABLE,m_bFocusEnable);
}

void CCOMCam::OnBnClickedBtnFocus()
{
	UpdateData(TRUE);
	if(m_iFocus>2100) m_iFocus = 2100;
	if(m_iFocus<900) m_iFocus = 900;
	UpdateData(FALSE);
	m_SLDFocus.SetPos(m_iFocus);
	MVC_SetParameter(pDemoDlg->m_iDevIndex,MVCADJ_FOCUSPOSITION,m_iFocus);
}
