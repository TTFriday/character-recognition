// COMSave.cpp : implementation file
//

#include "stdafx.h"
#include "MVCGEVLite.h"
#include "MVCGEVLiteDlg.h"
#include "COMSave.h"

extern CMVCGEVLiteDlg *pDemoDlg; //��������

// CCOMSave dialog

IMPLEMENT_DYNAMIC(CCOMSave, CDialog)

CCOMSave::CCOMSave(CWnd* pParent /*=NULL*/)
	: CDialog(CCOMSave::IDD, pParent)
	, m_iMulti(1)
{
	m_Compressor = new COMPVARS();
}

CCOMSave::~CCOMSave()
{
	if(m_Compressor)
	{
		delete m_Compressor;
		m_Compressor = NULL;
	}
}

void CCOMSave::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCOMSave)
	DDX_Text(pDX, IDC_EDT_Multi, m_iMulti);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CMB_PICTYPE, m_cPicType);
}


BEGIN_MESSAGE_MAP(CCOMSave, CDialog)
	//{{AFX_MSG_MAP(CCOMSave)
	ON_BN_CLICKED(IDC_BTN_Single, OnBnClickedBtnSingle)
	ON_BN_CLICKED(IDC_BTN_Multiple, OnBnClickedBtnMultiple)
	ON_BN_CLICKED(IDC_BTN_Coder, OnBTNCoder)
	ON_BN_CLICKED(IDC_BTN_AVISave, OnBTNAVISave)
	ON_BN_CLICKED(IDC_BTN_AVIPause, OnBTNAVIPause)
	ON_CBN_SELCHANGE(IDC_CMB_PICTYPE, OnSelchangeCmbPicType)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_SELECTPATH, &CCOMSave::OnBnClickedBtnSelectpath)
END_MESSAGE_MAP()


// CCOMSave message handlers

void CCOMSave::OnBnClickedBtnSingle()
{
	pDemoDlg->m_bImgSaveOnce = 1;
}

void CCOMSave::OnBnClickedBtnMultiple()
{
	UpdateData(TRUE);
	pDemoDlg->m_bImgSaveOnce = m_iMulti==0?1:m_iMulti;
	GetDlgItem(IDC_BTN_Multiple)->EnableWindow(0);
	GetDlgItem(IDC_EDT_Multi)->EnableWindow(0);
	GetDlgItem(IDC_BTN_Single)->EnableWindow(0);
}

void CCOMSave::MultiFlag(int lIndex)
{
	if(lIndex>0)
	{
		GetDlgItem(IDC_BTN_Multiple)->SetWindowText(Int2Cstr(lIndex));
	}
	else
	{
		GetDlgItem(IDC_BTN_Multiple)->SetWindowText("��֡��ͼ");
		GetDlgItem(IDC_BTN_Multiple)->EnableWindow(1);
		GetDlgItem(IDC_EDT_Multi)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Single)->EnableWindow(1);
	}
}

void CCOMSave::CompressFlag(int lIndex)
{
	if(lIndex>0)
	{
		GetDlgItem(IDC_EDT_AVINum)->SetWindowText(Int2Cstr(lIndex));
	}
	else
	{
		GetDlgItem(IDC_EDT_AVINum)->SetWindowText("");
	}
}

BOOL CCOMSave::GetCompressorName(COMPVARS *aCOMPVARS, CString &aName)
{
	if( aCOMPVARS == NULL )	return FALSE;
	
	//��ʼ��IC��Ϣ
	ICINFO lICINFO;
	memset( &lICINFO, 0, sizeof( lICINFO ) );
	lICINFO.dwSize = sizeof( lICINFO );
	// ���δѡ������������ؿմ�
	if( aCOMPVARS->fccType == 0 || aCOMPVARS->fccHandler == 0 )
	{
		aName = "";
		return TRUE;
	}
	// first check if this is the Uncompressed Frames selection ('DIB ')
	if( mmioFOURCC('D','I','B',' ') == aCOMPVARS->fccHandler )
	{
		aName = "Full Frames (Uncompressed)";
		return TRUE;
	}
	HIC lIC = ICOpen( aCOMPVARS->fccType, aCOMPVARS->fccHandler, ICMODE_QUERY );
	if( lIC == NULL )
	{
		DumpInfo("Cannot open the video compressor!");
	}
	if( ICGetInfo( lIC, &lICINFO, sizeof( lICINFO ) ) == 0 )
	{
		DumpInfo("Cannot get compressor information!");
	}
	if( ICClose( lIC ) != ICERR_OK )
	{
		DumpInfo("Cannot close compressor!");
	}
	aName = "";
	for( int lIdx = 0; lIdx < sizeof( lICINFO.szDescription ) && lICINFO.szDescription[ lIdx ] != 0; lIdx++ )
	{
		aName += (char)lICINFO.szDescription[ lIdx ];
	}
	return TRUE;
}

void CCOMSave::OnBTNCoder() 
{
	memset(m_Compressor, 0, sizeof(COMPVARS));
	m_Compressor->cbSize = sizeof( COMPVARS );
	// ����������ѡ����û�ѡ��
	if( !ICCompressorChoose( GetSafeHwnd(), ICMF_CHOOSE_ALLCOMPRESSORS, NULL, NULL, m_Compressor, "ѡ�������" ) )
	{
		return;
	}
	else
	{
		//m_Compressor->fccHandler = lCOMPVARS.fccHandler; //Ĭ��Ϊȫ֡��ѹ��
		CString lCodecName;
		if( !GetCompressorName( m_Compressor, lCodecName ) )
		{
			GetDlgItem(IDC_BTN_AVISave)->EnableWindow(0);
			GetDlgItem(IDC_BTN_AVIPause)->EnableWindow(0);
			return;
		}
		else
		{
			//DumpInfo("m_Compressor fccHandle is %x",m_Compressor->fccHandler);
			GetDlgItem(IDC_EDT_CoderName)->SetWindowText(lCodecName);
			GetDlgItem(IDC_BTN_AVISave)->EnableWindow(1);
			GetDlgItem(IDC_BTN_AVIPause)->EnableWindow(1);
		}
	}
}

void CCOMSave::OnBTNAVISave() 
{
	if(!pDemoDlg->m_bAviEnable)
	{
		//��ʼAVI¼��
		CString TimeName;
		char FileName[255];
		GetTimeAsFileName(TimeName);
		sprintf(FileName,"MVAVI-DEV%d-%s.avi",pDemoDlg->m_iDevIndex,TimeName);
		pDemoDlg->m_iImgWidth = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_WIDTH);
		pDemoDlg->m_iImgHeight = MVC_GetParameter(pDemoDlg->m_iDevIndex,MVCADJ_HEIGHT);
		//m_Compressor->hic = ICOpen( m_Compressor->fccType, m_Compressor->fccHandler, ICMODE_FASTCOMPRESS);
		if(MVC_SubAVIStart(pDemoDlg->m_iDevIndex,0,m_Compressor,FileName,pDemoDlg->m_iImgWidth,pDemoDlg->m_iImgHeight,pDemoDlg->m_bColor?3:1,30)!=CY_RESULT_OK)
		{
			OutputDebugString("AVI Start Not OK!");
			return;
		}
		pDemoDlg->m_bAviEnable = 1;
		pDemoDlg->m_bAviSaving = 1;
		GetDlgItem(IDC_BTN_AVISave)->SetWindowText("ֹͣ¼��");
		GetDlgItem(IDC_BTN_AVIPause)->EnableWindow(1);
		GetDlgItem(IDC_BTN_Coder)->EnableWindow(0);
	}
	else
	{
		//ֹͣAVI¼��
		pDemoDlg->m_bAviSaving = 0;
		Sleep(100);
		MVC_SubAVIStop(pDemoDlg->m_iDevIndex,0);
		pDemoDlg->m_bAviEnable = 0;
		pDemoDlg->m_iAviSavNum = 0;
		CompressFlag(0);
		GetDlgItem(IDC_BTN_AVISave)->SetWindowText("����¼��");
		GetDlgItem(IDC_BTN_AVIPause)->EnableWindow(0);
		GetDlgItem(IDC_BTN_Coder)->EnableWindow(1);
	}
}

void CCOMSave::OnBTNAVIPause() 
{
	pDemoDlg->m_bAviSaving = !pDemoDlg->m_bAviSaving;
	if(pDemoDlg->m_bAviSaving)
	{
		GetDlgItem(IDC_BTN_AVIPause)->SetWindowText("��ͣ¼��");
	}
	else
	{
		GetDlgItem(IDC_BTN_AVIPause)->SetWindowText("����¼��");
	}
}

BOOL CCOMSave::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString lCodecName;
	GetCompressorName( m_Compressor, lCodecName );
	GetDlgItem(IDC_EDT_CoderName)->SetWindowText(lCodecName);

	m_cPicType.SetCurSel(pDemoDlg->m_bSaveType);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CCOMSave::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_ESCAPE) 
	{ 
		return TRUE; 
	} 

	if(pMsg-> message==WM_KEYDOWN && pMsg-> wParam==VK_RETURN) 
	{ 
		return TRUE; 
	} 
	else 
	{ 
		return CDialog::PreTranslateMessage(pMsg); 
	}
}

void CCOMSave::OnSelchangeCmbPicType() 
{
	UpdateData(TRUE);
	pDemoDlg->m_bSaveType = m_cPicType.GetCurSel();
}

CString CCOMSave::GetSelFolder()
{
	char szSelected[MAX_PATH]; //��������ļ���·��
	CString m_strFileOut;
	BROWSEINFO bi;
	LPITEMIDLIST pidl;
	bi.hwndOwner = NULL;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = szSelected;
	bi.lpszTitle = "ѡ������ļ�·��";
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	bi.lpfn = NULL;
	bi.lParam = NULL;
	bi.iImage = NULL;
	if((pidl = SHBrowseForFolder(&bi)) != NULL)
	{
		if(SUCCEEDED(SHGetPathFromIDList(pidl, szSelected))) //�õ��ļ��е�ȫ·
		{
			m_strFileOut = szSelected;
			m_strFileOut += "\\";
		}
	}
	return m_strFileOut;
}

void CCOMSave::OnBnClickedBtnSelectpath()
{
	pDemoDlg->m_sSavePath = GetSelFolder();
	GetDlgItem(IDC_EDT_PATH)->SetWindowText(pDemoDlg->m_sSavePath);
}
