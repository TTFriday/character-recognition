import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from Ui_camera import Ui_camera
import cv2
import numpy as np
import time
from video import Video


# 打开摄像头多线程类
class Camera_Thrade(QThread):
    c = 1
    sign = pyqtSignal(object)
    def __init__(self):
        super(Camera_Thrade, self).__init__()
        
    def run(self):
        capture = cv2.VideoCapture(0)
        while(True):
            if self.c == 1:
                # 获取一帧视频流
                ret, frame = capture.read()
                img = frame.astype(np.uint8)

                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                self.sign.emit(img)
            else:
                break

    def stop(self):
        self.c = 0
        print("self.flag === 0")

class Camera(QDialog, Ui_camera):
    a = 1 #自定义变量作为摄像头关闭标识
    flag = 0 #自定义变量作为摄像头采集标识
    save_complement = 1  #自定义变量作为摄像头采集标识
    b = 0   #自定义变量作采集并显示按下采集按钮后的第一帧在相应的显示框标识
    def __init__(self):         
        super(Camera, self).__init__()
        self.setupUi(self)

        #初始设置采集按钮不可点击
        self.pushButton_startCollect.setEnabled(False)
        self.pushButton_endCollect.setEnabled(False)

        #功能连接
        self.pushButton_cameraOpen.clicked.connect(self.cameraOpen)
        self.pushButton_cameraClose.clicked.connect(self.cameraClose)
        self.pushButton_startCollect.clicked.connect(self.startCollect)
        self.pushButton_endCollect.clicked.connect(self.endCollect)
        self.pushButton_5.clicked.connect(self.ToVideo)
        
      
    #打开摄像头
    def cameraOpen(self):
        #打开摄像头的同时要设置采集按钮可点击
        self.pushButton_startCollect.setEnabled(True)
        self.pushButton_endCollect.setEnabled(True)
        #创建打开摄像头线程
        self.thread_camera = Camera_Thrade()   
        self.thread_camera.sign.connect(self.callback_camera)
        self.thread_camera.start()    
    def callback_camera(self, img):
        if self.a == 1:
            x = img.shape[1]
            y = img.shape[0]
            frame = QImage(img, x, y, QImage.Format_RGB888)
            pix = QPixmap.fromImage(frame)
            item = QGraphicsPixmapItem(pix)
            self.scene = QGraphicsScene()  #创建画布场景 
            self.scene.addItem(item)
            self.graphicsView_camera.setScene(self.scene)
            self.graphicsView_camera.show()
            #判断是否点击了采集，并显示一帧图像
            if (self.flag == 1) and (self.save_complement == 0):
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                time_filesave = time.strftime("%Y%m%d%H%M%S")
                print(time_filesave)
                cv2.imwrite("./Camera-Pic/image-Save{}.jpg".format(time_filesave), img)
                print('图像采集1')
            elif self.flag == 1 and self.save_complement == 1:
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                time_filesave = time.strftime("%Y%m%d%H%M%S")
                cv2.imwrite("./Camera-Pic/image-Save{}.jpg".format(time_filesave), img)
                print('图像采集2')
                self.scene1 = QGraphicsScene()  #创建画布场景 
                self.scene1.addItem(item)
                self.graphicsView_2.setScene(self.scene1)
                self.graphicsView_2.show()
                self.save_complement = 0
        elif self.a == 0:
            self.scene.clear()
            self.a = 1 
       
    #摄像头采集
    def cameraClose(self):
        self.a = 0
        self.thread_camera.stop()
        self.pushButton_startCollect.setEnabled(False)
        self.pushButton_endCollect.setEnabled(False)
    #开始采集
    def startCollect(self):
        self.flag = 1
        self.save_complement = 1 
        if self.b == 0:
            print('按下采集')
            self.b += 1
        else:
            self.scene1.clear()
            print('按下采集')

    #结束采集
    def endCollect(self):
        self.flag = -1

    #转到视频界面
    def ToVideo(self):
        self.hide()
        # recognition.hide()
        self.video = Video()
        self.video.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    camera = Camera()
    camera.show()
    sys.exit(app.exec_())