
import sys
from tracemalloc import start
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from Ui_video import Ui_Video

import cv2
import numpy as np
import time


# 打开视频多线程类
class Video_Thread(QThread):
    sign = pyqtSignal(object)
    c = 1
    def __init__(self):
        super(Video_Thread, self).__init__()
        self.mutex = QMutex()
        self.mutex.lock()
        self.cond = QWaitCondition()

    def run(self):
        print('启动线程')
        print('11111111111111111111111111111',fn)
        video = cv2.VideoCapture(fn)
        frame_count = video.get(cv2.CAP_PROP_FPS)
        while(self.c):
            time.sleep(1/frame_count)
            ret, frame1 = video.read()
            self.sign.emit(frame1)


class Video(QDialog, Ui_Video):
    start = 1 #自定义变量判断是否读取视频帧
    cx = 0 #自定义变量判断是否读取视频帧
    shot_param = 0 #自定义变量判断是否截图
    save_param = 0 #自定义变量判断是否保存
    def __init__(self):
        super(Video, self).__init__()
        self.setupUi(self)

        # 初始设置部分功能按钮不可点击
        self.pushButton_VideoShot.setEnabled(False)
        self.pushButton_VideoStop.setEnabled(False)
        self.pushButton_VideoStart.setEnabled(False)
        self.pushButton_ImageSave.setEnabled(False)

        #功能按钮连接槽函数
        self.pushButton_VideoOpen.clicked.connect(self.VideoOpen)
        self.pushButton_VideoStart.clicked.connect(self.VideoStart)
        self.pushButton_VideoStop.clicked.connect(self.Videostop)
        self.pushButton_ToCamera.clicked.connect(self.ToCamera)
        self.pushButton_ToWork.clicked.connect(self.ToRecogniton)
        self.pushButton_VideoShot.clicked.connect(self.ImageShot)
        self.pushButton_ImageSave.clicked.connect(self.ImageSave)

    # 打开视频
    def VideoOpen(self):
        self.pushButton_VideoStart.setEnabled(True)
        self.pushButton_VideoStop.setEnabled(True)

        filename, filetype = QFileDialog.getOpenFileName(self, '请选择视频文件', '/', '*.mp4')
        global fn 
        fn = filename
        self.video_Thread = Video_Thread()
        self.video_Thread.sign.connect(self.callback_Video)
        self.video_Thread.start()
    # 打开视频多线程回调函数
    def callback_Video(self, frame1):
        if self.start == 1 or self.cx == 1:
            if self.shot_param == 0 :
                img = frame1.astype(np.uint8)
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                x = img.shape[1]  # 获取图像大小
                y = img.shape[0]
                self.zoomscale = 1  # 初始化图片缩放尺度
                frame1 = QImage(img, x, y, QImage.Format_RGB888)
                pix = QPixmap.fromImage(frame1)
                item = QGraphicsPixmapItem(pix)
                scene = QGraphicsScene()  #创建画布场景 
                scene.addItem(item)
                self.graphicsView_Video.setScene(scene)
                self.graphicsView_Video.show()
                self.start = 0
                if self.save_param == 1:
                    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                    time_filesave = time.strftime("%Y%m%d%H%M%S")
                    print(time_filesave)
                    cv2.imwrite("./Video-Pic/image-Save{}.jpg".format(time_filesave), img)
                    self.save_param = 0
            elif self.shot_param == 1:
                img = frame1.astype(np.uint8)
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                x = img.shape[1]  # 获取图像大小
                y = img.shape[0]
                self.zoomscale = 1  # 初始化图片缩放尺度
                frame1 = QImage(img, x, y, QImage.Format_RGB888)
                pix = QPixmap.fromImage(frame1)
                item = QGraphicsPixmapItem(pix)
                scene = QGraphicsScene()  #创建画布场景 
                scene.addItem(item)
                self.graphicsView_Video.setScene(scene)
                self.graphicsView_Video.show()
                self.graphicsView_Image.setScene(scene)
                self.graphicsView_Image.show()
                if self.save_param == 1:
                    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                    time_filesave = time.strftime("%Y%m%d%H%M%S")
                    print(time_filesave)
                    cv2.imwrite("./Video-Pic/image-Save{}.jpg".format(time_filesave), img)

                self.shot_param = 0
            

        
            

    
    def VideoStart(self):
        print('视频播放')
        self.cx = 1
        self.pushButton_VideoStop.setEnabled(True)
        self.pushButton_VideoShot.setEnabled(True)
        self.pushButton_VideoStart.setEnabled(False)

    def Videostop(self):
        print('视频停止')
        self.pushButton_VideoStop.setEnabled(False)
        self.pushButton_VideoStart.setEnabled(True)
        self.cx = 0

    def ImageShot(self):
        self.shot_param = 1
        self.pushButton_ImageSave.setEnabled(True)

    def ImageSave(self):
        self.save_param = 1

    #转到摄像头界面 
    def ToCamera(self):
        self.hide()
        from camera import Camera
        self.camera = Camera()
        self.camera.show()

    #转到识别界面
    def ToRecogniton(self):
        self.hide()
        from recognition import Recognition
        self.recognition = Recognition()
        self.recognition.show()
        

