//
// Created by Lv,Xiangxiang on 2020/7/11.
// Copyright (c) 2020 Li,Xiaoyang(SYS). All rights reserved.
//

#import "OcrData.h"


@implementation OcrData {

}
@end