# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'recognition.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Recognition(object):
    def setupUi(self, Recognition):
        Recognition.setObjectName("Recognition")
        Recognition.resize(1411, 496)
        self.graphicsView_Image = QtWidgets.QGraphicsView(Recognition)
        self.graphicsView_Image.setGeometry(QtCore.QRect(120, 10, 640, 480))
        self.graphicsView_Image.setMinimumSize(QtCore.QSize(640, 480))
        self.graphicsView_Image.setMaximumSize(QtCore.QSize(640, 480))
        self.graphicsView_Image.setObjectName("graphicsView_Image")
        self.layoutWidget = QtWidgets.QWidget(Recognition)
        self.layoutWidget.setGeometry(QtCore.QRect(0, 20, 114, 451))
        self.layoutWidget.setObjectName("layoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.pushButton_ToCamere = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_ToCamere.setObjectName("pushButton_ToCamere")
        self.verticalLayout.addWidget(self.pushButton_ToCamere)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.pushButton_ImageOpen = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_ImageOpen.setObjectName("pushButton_ImageOpen")
        self.verticalLayout.addWidget(self.pushButton_ImageOpen)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem1)
        self.pushButton_ImageLast = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_ImageLast.setObjectName("pushButton_ImageLast")
        self.verticalLayout.addWidget(self.pushButton_ImageLast)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem2)
        self.pushButton_ImageNext = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_ImageNext.setObjectName("pushButton_ImageNext")
        self.verticalLayout.addWidget(self.pushButton_ImageNext)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)
        self.pushButton_ImageRsult = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_ImageRsult.setObjectName("pushButton_ImageRsult")
        self.verticalLayout.addWidget(self.pushButton_ImageRsult)
        self.textEdit_result = QtWidgets.QTextEdit(Recognition)
        self.textEdit_result.setGeometry(QtCore.QRect(770, 10, 640, 480))
        self.textEdit_result.setMinimumSize(QtCore.QSize(640, 480))
        self.textEdit_result.setMaximumSize(QtCore.QSize(640, 480))
        self.textEdit_result.setObjectName("textEdit_result")

        self.retranslateUi(Recognition)
        QtCore.QMetaObject.connectSlotsByName(Recognition)

    def retranslateUi(self, Recognition):
        _translate = QtCore.QCoreApplication.translate
        Recognition.setWindowTitle(_translate("Recognition", "字符识别"))
        self.pushButton_ToCamere.setText(_translate("Recognition", "<-------"))
        self.pushButton_ImageOpen.setText(_translate("Recognition", "读取图片"))
        self.pushButton_ImageLast.setText(_translate("Recognition", "上一张"))
        self.pushButton_ImageNext.setText(_translate("Recognition", "下一张"))
        self.pushButton_ImageRsult.setText(_translate("Recognition", "识别"))

