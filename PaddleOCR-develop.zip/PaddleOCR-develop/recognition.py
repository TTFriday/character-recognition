import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from Ui_recognition import Ui_Recognition
#from pd.tools.infer.predict_system import *
from tools.infer.predict_system import * #modify by peter 20220311
import cv2
import numpy as np

class Recognition(QThread):
    sign = pyqtSignal(object)
    def __init__(self):
        super(Recognition, self).__init__()
        self.mutex = QMutex()
        self.mutex.lock()
        self.cond = QWaitCondition()
    def run(self):
        print('启动线程')

class Recognition(QDialog, Ui_Recognition):
    flag = 0
    current = 0 #自定义变量，当读取多张图像时，上下切换查看情况下 用于保存当前图像的位置
    fileName = [] # 自定义列表，用于装载同时读取多张图像
    def __init__(self):
        super(Recognition, self).__init__()
        self.setupUi(self)

        self.pushButton_ImageLast.setEnabled(False)
        self.pushButton_ImageNext.setEnabled(False)

        self.pushButton_ImageOpen.clicked.connect(self.imageOpen)  
        self.pushButton_ImageLast.clicked.connect(self.lastImage)
        self.pushButton_ImageNext.clicked.connect(self.nextImage)

        self.pushButton_ToCamere.clicked.connect(self.toVideo)
        self.show()
        #add by peter 20220311
        self.pushButton_ImageRsult.clicked.connect(self.OCR_work)

    #打开图像
    def imageOpen(self):
        filenames, filetype = QFileDialog.getOpenFileNames(self, '请选择图片文件', '/', '*.jpg;; *.png;; *.jpeg')
        self.images = len(filenames)
        if len(filenames) >= 2:
            self.pushButton_ImageLast.setEnabled(True)
            self.pushButton_ImageNext.setEnabled(True)
        self.fileName = filenames
        
        if not filenames:
            result = QMessageBox.warning(
                self, "温馨提示您", "请先选择图片文件！", QMessageBox.Yes)
            if result == QMessageBox.Yes:
                self.imageOpen()
        self.image_show(filenames[self.current])

    def image_show(self, filenames):
        self.filename = filenames
        self.img = cv2.imread(filenames)
        self.img = cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)
        x = self.img.shape[1]  # 获取图像大小
        y = self.img.shape[0]
        frame = QImage(self.img, x, y, QImage.Format_RGB888)
        pix = QPixmap.fromImage(frame)
        item = QGraphicsPixmapItem(pix)
        scene = QGraphicsScene()  #创建画布场景 
        scene.addItem(item)
        self.graphicsView_Image.setScene(scene)
        self.graphicsView_Image.show()

    # 下一张
    def nextImage(self):
        self.current = (self.current + 1) % self.images
        self.image_show(self.fileName[self.current])

    # 上一张
    def lastImage(self):
        self.current = (self.current - 1) % self.images
        self.image_show(self.fileName[self.current])

    # 转到视频界面
    def toVideo(self):
        self.hide()
        from video import Video
        self.video = Video()
        self.video.show()
# self.img就是要进行识别的图像，可以直接用到paddle函数里面作为参数

    #add by peter 20220311 来自SteelPlate_OCR.py第90-92行
    def OCR_work(self):
        print("self.filename[self.current]",self.filename)
        result_output_ocr = SteelPlateOCR(utility.parse_args(),self.filename)
        print('result_output_ocr:',result_output_ocr)
        #self.resultOutput.setPlainText(result_output_ocr)
        self.textEdit_result.setPlainText(result_output_ocr)   #modify by peter 20220311


if __name__ == "__main__":
    app = QApplication(sys.argv)
    recognition = Recognition()
    sys.exit(app.exec_())