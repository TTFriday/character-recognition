# Waiting for your contribution

PaddleOCR welcomes you to provide multilingual corpus for us to synthesize more data to optimize the model.

If you are interested, you can submit the corpus text to this directory and name it with {language}_corpus.txt.
PaddleOCR thanks for your contribution.